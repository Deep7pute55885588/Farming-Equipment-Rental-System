<?php
include "db.php";

echo "<h2>Database Update Status</h2>";

// Check and add rental_start_date column if it doesn't exist
$check_column = "SHOW COLUMNS FROM `orders` LIKE 'rental_start_date'";
$result = mysqli_query($con, $check_column);

if (mysqli_num_rows($result) == 0) {
    // Column doesn't exist, add it
    $alter_table = "ALTER TABLE `orders` ADD COLUMN `rental_start_date` DATE";
    
    if (mysqli_query($con, $alter_table)) {
        echo "Rental start date column added successfully!<br>";
    } else {
        echo "Error adding rental start date column: " . mysqli_error($con) . "<br>";
    }
} else {
    echo "Rental start date column already exists.<br>";
}

// Check and add rental_end_date column if it doesn't exist
$check_column = "SHOW COLUMNS FROM `orders` LIKE 'rental_end_date'";
$result = mysqli_query($con, $check_column);

if (mysqli_num_rows($result) == 0) {
    // Column doesn't exist, add it
    $alter_table = "ALTER TABLE `orders` ADD COLUMN `rental_end_date` DATE";
    
    if (mysqli_query($con, $alter_table)) {
        echo "Rental end date column added successfully!<br>";
    } else {
        echo "Error adding rental end date column: " . mysqli_error($con) . "<br>";
    }
} else {
    echo "Rental end date column already exists.<br>";
}

// Check and add rental_status column if it doesn't exist
$check_column = "SHOW COLUMNS FROM `orders` LIKE 'rental_status'";
$result = mysqli_query($con, $check_column);

if (mysqli_num_rows($result) == 0) {
    // Column doesn't exist, add it
    $alter_table = "ALTER TABLE `orders` ADD COLUMN `rental_status` ENUM('active', 'completed', 'cancelled') DEFAULT 'active'";
    
    if (mysqli_query($con, $alter_table)) {
        echo "Rental status column added successfully!<br>";
    } else {
        echo "Error adding rental status column: " . mysqli_error($con) . "<br>";
    }
} else {
    echo "Rental status column already exists.<br>";
}

// Also add vendor_id to products table if it doesn't exist
$check_vendor_column = "SHOW COLUMNS FROM `products` LIKE 'vendor_id'";
$result2 = mysqli_query($con, $check_vendor_column);

if (mysqli_num_rows($result2) == 0) {
    // Column doesn't exist, add it
    $alter_products = "ALTER TABLE `products` ADD COLUMN `vendor_id` INT(11) DEFAULT 0";
    
    if (mysqli_query($con, $alter_products)) {
        echo "Vendor ID column added to products table!<br>";
    } else {
        echo "Error adding vendor ID column: " . mysqli_error($con) . "<br>";
    }
} else {
    echo "Vendor ID column already exists in products table.<br>";
}

echo "<h3>Database update process completed!</h3>";

mysqli_close($con);
?>