$(document).ready(function(){
    // Function to calculate hours between dates
    function calculateHours(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        const diff = end.getTime() - start.getTime();
        return Math.ceil(diff / (1000 * 60 * 60)); // Convert milliseconds to hours
    }

    // Function to update cart total
    function updateCartTotal(row) {
        const startDate = $(row).find('.rental-start').val();
        const endDate = $(row).find('.rental-end').val();
        const ratePerHour = parseFloat($(row).find('.rate-per-hour').val());

        if(startDate && endDate) {
            const hours = calculateHours(startDate, endDate);
            const total = hours * ratePerHour;
            $(row).find('.hours').val(hours);
            $(row).find('.total-cost').val(total.toFixed(2));
            
            // Update hidden fields for form submission
            $(row).find('input[name="rental_start_date[]"]').val(startDate);
            $(row).find('input[name="rental_end_date[]"]').val(endDate);
            $(row).find('input[name="rental_hours[]"]').val(hours);
        }
    }

    // Event handler for date changes
    $(document).on('change', '.rental-start, .rental-end', function() {
        const row = $(this).closest('.cart-row');
        updateCartTotal(row);
    });

    // Validate dates before form submission
    $('#cart-form').on('submit', function(e) {
        const currentDate = new Date();
        let isValid = true;

        $('.cart-row').each(function() {
            const startDate = new Date($(this).find('.rental-start').val());
            const endDate = new Date($(this).find('.rental-end').val());

            if(startDate < currentDate) {
                alert('Rental start date cannot be in the past');
                isValid = false;
                return false;
            }

            if(endDate <= startDate) {
                alert('Rental end date must be after start date');
                isValid = false;
                return false;
            }
        });

        if(!isValid) {
            e.preventDefault();
        }
    });
});