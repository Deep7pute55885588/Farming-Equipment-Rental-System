<?php
session_start();
include "db.php";

if (isset($_POST["updateCartDates"])) {
	if(!isset($_SESSION["uid"])) {
		echo "<div class='alert alert-danger'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>Please login first!</b>
			</div>";
		exit();
	}
    
	$id = intval($_POST["id"]);
	$start_date = mysqli_real_escape_string($con, $_POST["start_date"]);
	$end_date = mysqli_real_escape_string($con, $_POST["end_date"]);
    
	// Validate dates
	if(strtotime($start_date) < strtotime('today')) {
		echo "<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>Start date cannot be in the past!</b>
			</div>";
		exit();
	}
    
	if(strtotime($end_date) <= strtotime($start_date)) {
		echo "<div class='alert alert-warning'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>End date must be after start date!</b>
			</div>";
		exit();
	}
    
	$sql = "UPDATE cart 
			SET rental_start_date = '$start_date', 
				rental_end_date = '$end_date' 
			WHERE p_id = '$id' AND user_id = '$_SESSION[uid]'";
            
	if(mysqli_query($con, $sql)) {
		// Recalculate final cost for the session
		$final = 0;
		$uid = $_SESSION['uid'];
		$calc_sql = "SELECT a.product_price, b.rental_start_date, b.rental_end_date, b.qty FROM products a, cart b WHERE a.product_id=b.p_id AND b.user_id='$uid'";
		$calc_q = mysqli_query($con, $calc_sql);
		if ($calc_q) {
			while ($r = mysqli_fetch_array($calc_q)) {
				$pprice = $r['product_price'];
				$rs = $r['rental_start_date'];
				$re = $r['rental_end_date'];
				$q = $r['qty'];
				if (!empty($rs) && !empty($re)) {
					$hours = ceil((strtotime($re) - strtotime($rs)) / 3600);
					if ($hours < 1) $hours = 1;
					$final += $pprice * $hours;
				} else {
					$final += $pprice * $q;
				}
			}
		}
		$_SESSION['finalcost'] = $final;

		echo "<div class='alert alert-success'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>Rental dates updated successfully!</b>
			</div>";
	} else {
		echo "<div class='alert alert-danger'>
				<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>Failed to update rental dates. Please try again.</b>
			</div>";
	}
	exit();
}

?>