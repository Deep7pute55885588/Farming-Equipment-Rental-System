<?php


?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>FARMTECH</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css"/>
		<script>
		$(document).ready(function() {
			// Function to calculate hours between dates
			function calculateHours(startDate, endDate) {
				const start = new Date(startDate);
				const end = new Date(endDate);
				const diff = end.getTime() - start.getTime();
				return Math.ceil(diff / (1000 * 60 * 60)); // Convert milliseconds to hours
			}

			// Function to update cart totals
			function updateCartTotals() {
				let grandTotal = 0;
				$('.cart-item').each(function() {
					const startDate = $(this).find('.rental-start').val();
					const endDate = $(this).find('.rental-end').val();
					const ratePerHour = parseFloat($(this).data('price'));
					
					if(startDate && endDate) {
						const hours = calculateHours(startDate, endDate);
						const total = hours * ratePerHour;
						$(this).find('.hours').text(hours);
						$(this).find('.total').text(total.toFixed(2));
						grandTotal += total;
					}
				});
				$('.net_total').text('Total Rental Cost: Rs.' + grandTotal.toFixed(2));
			}

			// Handle rental date changes
			$(document).on('change', '.rental-start, .rental-end', function() {
				const row = $(this).closest('.cart-item');
				const startDate = row.find('.rental-start').val();
				const endDate = row.find('.rental-end').val();
				
				// Validate dates
				if(new Date(startDate) < new Date().setHours(0,0,0,0)) {
					alert('Start date cannot be in the past');
					$(this).val('');
					return;
				}
				
				if(endDate && new Date(endDate) <= new Date(startDate)) {
					alert('End date must be after start date');
					row.find('.rental-end').val('');
					return;
				}
				
				updateCartTotals();
			});

			// Update cart when dates are changed
			$(document).on('click', '.update', function(e) {
				e.preventDefault();
				const update_id = $(this).attr('update_id');
				const row = $(this).closest('.cart-item');
				const start_date = row.find('.rental-start').val();
				const end_date = row.find('.rental-end').val();
				
				if(!start_date || !end_date) {
					alert('Please select both start and end dates');
					return;
				}
				
				$.ajax({
					url: 'update_cart_dates.php',
					method: 'POST',
					data: {
						updateCartDates: 1,
						id: update_id,
						start_date: start_date,
						end_date: end_date
					},
					success: function(data) {
						$("#cart_msg").html(data);
						updateCartTotals();
					}
				});
			});

			// When user clicks Take On Rent, save all date inputs then redirect to payment
			$(document).on('click', '#take_on_rent', function(e) {
				e.preventDefault();
				var ids = [];
				var starts = [];
				var ends = [];
				$('.cart-item').each(function(){
					var pid = $(this).find('input[name="product_id[]"]').val();
					ids.push(pid);
					starts.push($(this).find('.rental-start').val());
					ends.push($(this).find('.rental-end').val());
				});
				$.ajax({
					url: 'update_all_cart_dates.php',
					method: 'POST',
					data: {ids: ids, starts: starts, ends: ends},
					success: function(resp) {
						try {
							var j = (typeof resp === 'object') ? resp : JSON.parse(resp);
							if (j.status === 'ok') {
								// redirect to payment
								window.location = 'cart_process.php';
							} else {
								$('#cart_msg').html('<div class="alert alert-danger">'+j.message+'</div>');
							}
						} catch(e) {
							$('#cart_msg').html('<div class="alert alert-danger">Unexpected server response</div>');
						}
					}
				});
			});
			// Initialize totals on page load
			updateCartTotals();
		});
		</script>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-brand">FARMTECH</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="productview.php"><span class="glyphicon glyphicon-modal-window"></span>Equipments</a></li>
			</ul>
		</div>
	</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="cart_msg">
				<!--Cart Message--> 
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Cart Checkout</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-2 col-xs-2"><b>Action</b></div>
							<div class="col-md-2 col-xs-2"><b>Equipment Image</b></div>
							<div class="col-md-2 col-xs-2"><b>Equipment Name</b></div>
							<div class="col-md-2 col-xs-2"><b>Rental Start Date</b></div>
							<div class="col-md-2 col-xs-2"><b>Rental End Date</b></div>
							<div class="col-md-1 col-xs-1"><b>Hours</b></div>
							<div class="col-md-1 col-xs-1"><b>Rate/Hr</b></div>
							<div class="col-md-2 col-xs-2"><b>Total Cost</b></div>
						</div>
						<div id="cart_checkout"></div>
					<!--	<div class="row">
							<div class="col-md-2">
								<div class="btn-group">
									<a href="#" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
									<a href="" class="btn btn-primary"><span class="glyphicon glyphicon-ok-sign"></span></a>
								</div>
							</div>
							<div class="col-md-2"><img src='product_images/imges.jpg'></div>
							<div class="col-md-2">Product Name</div>
							<div class="col-md-2"><input type='text' class='form-control' value='1' ></div>
							<div class="col-md-2"><input type='text' class='form-control' value='5000' disabled></div>
							<div class="col-md-2"><input type='text' class='form-control' value='5000' disabled></div>
						</div> -->
						<!--<div class="row">
							<div class="col-md-8"></div>
							<div class="col-md-4">
								<b>Total $500000</b>
							</div> -->
						</div> 
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
			
		</div>


</body>	
</html>
















		