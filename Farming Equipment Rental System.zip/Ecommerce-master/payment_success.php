<?php

session_start();
if(!isset($_SESSION["uid"])){
	header("location:index.php");
}

function random_strings($length_of_string)
{
	
    // String of all alphanumeric character
    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
 
    // Shuffle the $str_result and returns substring
    // of specified length
    return substr(str_shuffle($str_result),
                       0, $length_of_string);
}

// Include the Products class
include_once("admin/classes/Products.php");
include_once("db.php");

$trx_id = random_strings(17);
$p_st = "completed";
$cm_user_id = $_SESSION["uid"];
$mobile = isset($_SESSION["mobile"]) ? $_SESSION["mobile"] : "";
$f_name = isset($_SESSION["name"]) ? $_SESSION["name"] : "";

$sql = "SELECT p_id, qty, rental_start_date, rental_end_date FROM cart WHERE user_id = '$cm_user_id'";
$query = mysqli_query($con,$sql);
if (mysqli_num_rows($query) > 0) {
	$product_orders = [];
	while ($row=mysqli_fetch_array($query)) {
		$product_orders[] = [
			'product_id' => $row["p_id"],
			'qty' => $row["qty"],
			'start_date' => $row["rental_start_date"],
			'end_date' => $row["rental_end_date"]
		];
	}

	// Process each order using the Products class
	$products = new Products();
	$order_success = true;
	$order_messages = [];

	foreach ($product_orders as $order) {
		$result = $products->processRentalOrder(
			$order['product_id'],
			$order['qty'],
			$order['start_date'],
			$order['end_date'],
			$cm_user_id
		);
		
		if ($result['status'] != 202) {
			$order_success = false;
			$order_messages[] = "Failed to process order for product ID " . $order['product_id'] . ": " . $result['message'];
		}
	}

	// If all orders were processed successfully, clear the cart
	if ($order_success) {
		$sql = "DELETE FROM cart WHERE user_id = '$cm_user_id'";
		mysqli_query($con,$sql);
	}
	
	if ($order_success) {
?>
		<!DOCTYPE html>
		<html>
			<head>
				<meta charset="UTF-8">
				<title>FARMTECH</title>
				<link rel="stylesheet" href="css/bootstrap.min.css"/>
				<script src="js/jquery2.js"></script>
				<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
				<script src="js/bootstrap.min.js"></script>
				<script src="main.js"></script>
				<style>
					table tr td {padding:10px;}
				</style>
			</head>
		<body>
			<div class="navbar navbar-inverse navbar-fixed-top">
				<div class="container-fluid">	
					<div class="navbar-header">
						<a href="#" class="navbar-brand">FARMTECH</a>
					</div>
					<ul class="nav navbar-nav">
						<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
						<li><a href="profile.php"><span class="glyphicon glyphicon-modal-window"></span>Equipments</a></li>
					</ul>
				</div>
			</div>
			<p><br/></p>
			<p><br/></p>
			<p><br/></p>
			<div class="container-fluid">
			
				<div class="row">
					<div class="col-md-2"></div>
					<div class="col-md-8">
						<div class="panel panel-default" style="display: flex; justify-content:space-between;">
							<div class="panel-heading" style="background-color:red;">
<lottie-player src="https://assets3.lottiefiles.com/packages/lf20_lc7svuzc.json"  background="transparent"  speed="1"  style="width: 300px; height: 300px;"    autoplay></lottie-player>
								
							</div>
							<div class="panel-body" >
								<h1>Thank You!</h1>
								<hr/>
								<p>Hello <?php echo "<b>".$_SESSION["name"]."</b>"; ?>,Your payment process is 
								successfully completed and your Transaction id is <b><?php echo $trx_id; ?></b><br/>
								You can continue your Shopping <br/></p>
								<a href="index.php" class="btn btn-success btn-lg">Continue Shopping</a>
							</div>
							<div class="panel-footer"></div>
						</div>
					</div>
					<div class="col-md-2"></div>
				</div>
            </div>
		</body>
		</html>

	<?php
	} else {
		// Display error messages
		echo "<h2>Error Processing Orders</h2>";
		foreach ($order_messages as $message) {
			echo "<p>" . $message . "</p>";
		}
		echo "<a href='cart.php' class='btn btn-primary'>Go Back to Cart</a>";
	}
} else {
    echo "<h2>No items in cart</h2>";
    echo "<a href='index.php' class='btn btn-primary'>Continue Shopping</a>";
}
?>