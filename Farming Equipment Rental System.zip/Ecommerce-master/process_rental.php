<?php
session_start();
include "db.php";

if(!isset($_SESSION["uid"])){
    header("location:index.php");
    exit();
}

if(isset($_POST["rental_start_date"]) && isset($_POST["rental_end_date"]) && isset($_POST["rental_hours"])) {
    $user_id = $_SESSION["uid"];
    $rental_start_dates = $_POST["rental_start_date"];
    $rental_end_dates = $_POST["rental_end_date"];
    $rental_hours = $_POST["rental_hours"];
    
    // Get cart items
    $cart_query = "SELECT c.*, p.product_title, p.product_price 
                   FROM cart c 
                   JOIN products p ON c.p_id = p.product_id 
                   WHERE c.user_id = '$user_id'";
    $cart_result = mysqli_query($con, $cart_query);
    
    $total_amount = 0;
    $success = true;
    
    // Start transaction
    mysqli_begin_transaction($con);
    
    try {
        $i = 0;
        while($cart_row = mysqli_fetch_array($cart_result)) {
            $product_id = $cart_row["p_id"];
            $product_price = $cart_row["product_price"];
            $rental_start = $rental_start_dates[$i];
            $rental_end = $rental_end_dates[$i];
            $hours = $rental_hours[$i];
            
            // Calculate cost
            $cost = $product_price * $hours;
            $total_amount += $cost;
            
            // Insert into orders
            $insert_order = "INSERT INTO orders (user_id, product_id, qty, p_status, rental_start_date, rental_end_date) 
                            VALUES ('$user_id', '$product_id', '1', 'pending', '$rental_start', '$rental_end')";
            
            if(!mysqli_query($con, $insert_order)) {
                throw new Exception("Failed to create order");
            }
            
            $i++;
        }
        
        // Clear cart
        $clear_cart = "DELETE FROM cart WHERE user_id = '$user_id'";
        if(!mysqli_query($con, $clear_cart)) {
            throw new Exception("Failed to clear cart");
        }
        
        // Commit transaction
        mysqli_commit($con);
        
        echo "success";
    } catch (Exception $e) {
        // Rollback transaction on error
        mysqli_rollback($con);
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request";
}
?>