<?php
session_start();
include_once "classes/Products.php";

// Test the equipment availability functionality
$products = new Products();

echo "<h2>Testing Equipment Availability</h2>";

// Test 1: Check current availability
echo "<h3>Current Availability</h3>";
$availability = $products->getEquipmentAvailability();
echo "<pre>" . print_r($availability, true) . "</pre>";

// Test 2: Check availability for a specific date
echo "<h3>Availability for Tomorrow</h3>";
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$availability_tomorrow = $products->getEquipmentAvailabilityByDate($tomorrow);
echo "<pre>" . print_r($availability_tomorrow, true) . "</pre>";

// Test 3: Check rental schedule
echo "<h3>Current Rental Schedule</h3>";
$schedule = $products->getRentalSchedule();
echo "<pre>" . print_r($schedule, true) . "</pre>";

?>