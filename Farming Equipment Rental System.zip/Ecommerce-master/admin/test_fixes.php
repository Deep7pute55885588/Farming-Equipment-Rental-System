<?php
session_start();
$_SESSION['admin_id'] = 1; // Simulate admin login for testing

include_once "classes/Products.php";

echo "<h2>Testing Fixes for Equipment Availability System</h2>";

// Test 1: Check if Products class can be instantiated without session errors
try {
    $products = new Products();
    echo "<p>✓ Products class instantiated successfully</p>";
} catch (Exception $e) {
    echo "<p>✗ Error instantiating Products class: " . $e->getMessage() . "</p>";
    exit;
}

// Test 2: Check availability for period function
echo "<h3>Testing checkAvailabilityForPeriod method</h3>";
try {
    $result = $products->checkAvailabilityForPeriod(1, '2025-11-09', '2025-11-10');
    if ($result['status'] == 202) {
        echo "<p>✓ Availability check successful</p>";
        echo "<pre>" . print_r($result['message'], true) . "</pre>";
    } else {
        echo "<p>✗ Availability check failed: " . $result['message'] . "</p>";
    }
} catch (Exception $e) {
    echo "<p>✗ Error in availability check: " . $e->getMessage() . "</p>";
}

echo "<h3>Fix Verification Complete</h3>";
?>