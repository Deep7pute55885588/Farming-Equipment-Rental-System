<?php
// Check if session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

class Products
{
	
	private $con;
	private $status_col; // detected order status column name (if any)

	function __construct()
	{
		include_once("Database.php");
		$db = new Database();
		$this->con = $db->connect();

		// Detect which order status column exists in the orders table (if any)
		$this->status_col = $this->detectOrderStatusColumn();
	}

	/**
	 * Detects an order status column on the `orders` table.
	 * Preference order: rental_status, order_status, p_status
	 * Returns column name string or null if none found.
	 */
	private function detectOrderStatusColumn() {
		$candidates = ['rental_status', 'order_status', 'p_status'];
		foreach ($candidates as $col) {
			$colEsc = $this->con->real_escape_string($col);
			$q = $this->con->query("SHOW COLUMNS FROM `orders` LIKE '{$colEsc}'");
			if ($q && $q->num_rows > 0) {
				return $col;
			}
		}
		return null;
	}

	/**
	 * Helper to prepare and bind parameters dynamically and return statement.
	 * $types is a string for bind_param types (i.e. 'ssi'), $params is array of values.
	 * Returns mysqli_stmt on success or false on failure.
	 */
	private function prepareAndBind($sql, $types = '', $params = []) {
		$stmt = $this->con->prepare($sql);
		if (!$stmt) {
			error_log("prepare failed: " . $this->con->error . " -- SQL: " . $sql);
			return false;
		}
		if ($types !== '' && count($params) > 0) {
			// bind_param requires references
			$bind_names = [];
			$bind_names[] = $types;
			for ($i = 0; $i < count($params); $i++) {
				$bind_name = 'bind' . $i;
				$$bind_name = $params[$i];
				$bind_names[] = &$$bind_name;
			}
			call_user_func_array([$stmt, 'bind_param'], $bind_names);
		}
		return $stmt;
	}

	public function getProducts(){
		// Get the logged in vendor/admin ID
		$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
		
		// Get current date for availability calculation
		$current_date = date('Y-m-d');
		
		$q = $this->con->query("SELECT 
			p.product_id, 
			p.product_title, 
			p.product_price, 
			p.product_qty,
			(p.product_qty - COALESCE(
				(SELECT COUNT(*) 
				FROM cart c 
				WHERE c.p_id = p.product_id 
				AND c.rental_start_date <= '$current_date' 
				AND c.rental_end_date >= '$current_date'), 0
			)) as available_qty,
			p.product_desc, 
			p.product_image, 
			p.product_keywords, 
			c.cat_title, 
			c.cat_id, 
			b.brand_id, 
			b.brand_title 
		FROM products p 
		JOIN categories c ON c.cat_id = p.product_cat 
		JOIN brands b ON b.brand_id = p.product_brand
		WHERE p.vendor_id = $vendor_id");
		
		$products = [];
		if ($q && $q->num_rows > 0) {
			while($row = $q->fetch_assoc()){
				$products[] = $row;
			}
			$_DATA['products'] = $products;
		} else {
			$_DATA['products'] = [];
		}

		$categories = [];
		$q2 = $this->con->query("SELECT * FROM categories");
		if ($q2 && $q2->num_rows > 0) {
			while($row = $q2->fetch_assoc()){
				$categories[] = $row;
			}
			$_DATA['categories'] = $categories;
		} else {
			$_DATA['categories'] = [];
		}

		$brands = [];
		$q3 = $this->con->query("SELECT * FROM brands");
		if ($q3 && $q3->num_rows > 0) {
			while($row = $q3->fetch_assoc()){
				$brands[] = $row;
			}
			$_DATA['brands'] = $brands;
		} else {
			$_DATA['brands'] = [];
		}

		return ['status'=> 202, 'message'=> $_DATA];
	}

	public function addProduct($product_name,
								$brand_id,
								$category_id,
								$product_desc,
								$product_qty,
								$product_price,
								$product_keywords,
								$file){


		$fileName = $file['name'];
		$fileNameAr= explode(".", $fileName);
		$extension = end($fileNameAr);
		$ext = strtolower($extension);

		if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
			
			// Size check in bytes; original code seemed to intend 2MB but used (1024 * 2) incorrectly.
			$maxBytes = 2 * 1024 * 1024; // 2MB
			if ($file['size'] <= $maxBytes) {
				
				$uniqueImageName = time()."_".$file['name'];
				$targetPath = $_SERVER['DOCUMENT_ROOT']."/Ecommerce-master/product_images/".$uniqueImageName;
				if (move_uploaded_file($file['tmp_name'], $targetPath)) {
					
					// Get the logged in vendor/admin ID
					$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
					
					$product_name_esc = $this->con->real_escape_string($product_name);
					$category_id_esc = $this->con->real_escape_string($category_id);
					$brand_id_esc = $this->con->real_escape_string($brand_id);
					$product_qty_esc = $this->con->real_escape_string($product_qty);
					$product_price_esc = $this->con->real_escape_string($product_price);
					$product_desc_esc = $this->con->real_escape_string($product_desc);
					$product_keywords_esc = $this->con->real_escape_string($product_keywords);
					$uniqueImageNameEsc = $this->con->real_escape_string($uniqueImageName);

					$q = $this->con->query("INSERT INTO `products`(`vendor_id`, `product_cat`, `product_brand`, `product_title`, `product_qty`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES ('$vendor_id', '$category_id_esc', '$brand_id_esc', '$product_name_esc', '$product_qty_esc', '$product_price_esc', '$product_desc_esc', '$uniqueImageNameEsc', '$product_keywords_esc')");

					if ($q) {
						return ['status'=> 202, 'message'=> 'Product Added Successfully..!'];
					}else{
						return ['status'=> 303, 'message'=> 'Failed to run query: ' . $this->con->error];
					}

				}else{
					return ['status'=> 303, 'message'=> 'Failed to upload image'];
				}

			}else{
				return ['status'=> 303, 'message'=> 'Large Image ,Max Size allowed 2MB'];
			}

		}else{
			return ['status'=> 303, 'message'=> 'Invalid Image Format [Valid Formats : jpg, jpeg, png]'];
		}

	}


	public function editProductWithImage($pid,
										$product_name,
										$brand_id,
										$category_id,
										$product_desc,
										$product_qty,
										$product_price,
										$product_keywords,
										$file){


		$fileName = $file['name'];
		$fileNameAr= explode(".", $fileName);
		$extension = end($fileNameAr);
		$ext = strtolower($extension);

		if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
			
			$maxBytes = 2 * 1024 * 1024; // 2MB
			if ($file['size'] <= $maxBytes) {
				
				$uniqueImageName = time()."_".$file['name'];
				$targetPath = $_SERVER['DOCUMENT_ROOT']."/Ecommerce-master/product_images/".$uniqueImageName;
				if (move_uploaded_file($file['tmp_name'], $targetPath)) {
					
					$pid_esc = $this->con->real_escape_string($pid);
					$product_name_esc = $this->con->real_escape_string($product_name);
					$brand_id_esc = $this->con->real_escape_string($brand_id);
					$category_id_esc = $this->con->real_escape_string($category_id);
					$product_desc_esc = $this->con->real_escape_string($product_desc);
					$product_qty_esc = $this->con->real_escape_string($product_qty);
					$product_price_esc = $this->con->real_escape_string($product_price);
					$product_keywords_esc = $this->con->real_escape_string($product_keywords);
					$uniqueImageNameEsc = $this->con->real_escape_string($uniqueImageName);

					$q = $this->con->query("UPDATE `products` SET 
										`product_cat` = '$category_id_esc', 
										`product_brand` = '$brand_id_esc', 
										`product_title` = '$product_name_esc', 
										`product_qty` = '$product_qty_esc', 
										`product_price` = '$product_price_esc', 
										`product_desc` = '$product_desc_esc', 
										`product_image` = '$uniqueImageNameEsc', 
										`product_keywords` = '$product_keywords_esc'
										WHERE product_id = '$pid_esc'");

					if ($q) {
						return ['status'=> 202, 'message'=> 'Product Modified Successfully..!'];
					}else{
						return ['status'=> 303, 'message'=> 'Failed to run query: ' . $this->con->error];
					}

				}else{
					return ['status'=> 303, 'message'=> 'Failed to upload image'];
				}

			}else{
				return ['status'=> 303, 'message'=> 'Large Image ,Max Size allowed 2MB'];
			}

		}else{
			return ['status'=> 303, 'message'=> 'Invalid Image Format [Valid Formats : jpg, jpeg, png]'];
		}

	}

	public function editProductWithoutImage($pid,
										$product_name,
										$brand_id,
										$category_id,
										$product_desc,
										$product_qty,
										$product_price,
										$product_keywords){

		if ($pid != null) {
			$pid_esc = $this->con->real_escape_string($pid);
			$product_name_esc = $this->con->real_escape_string($product_name);
			$brand_id_esc = $this->con->real_escape_string($brand_id);
			$category_id_esc = $this->con->real_escape_string($category_id);
			$product_desc_esc = $this->con->real_escape_string($product_desc);
			$product_qty_esc = $this->con->real_escape_string($product_qty);
			$product_price_esc = $this->con->real_escape_string($product_price);
			$product_keywords_esc = $this->con->real_escape_string($product_keywords);

			$q = $this->con->query("UPDATE `products` SET 
										`product_cat` = '$category_id_esc', 
										`product_brand` = '$brand_id_esc', 
										`product_title` = '$product_name_esc', 
										`product_qty` = '$product_qty_esc', 
										`product_price` = '$product_price_esc', 
										`product_desc` = '$product_desc_esc',
										`product_keywords` = '$product_keywords_esc'
										WHERE product_id = '$pid_esc'");

			if ($q) {
				return ['status'=> 202, 'message'=> 'Product updated Successfully'];
			}else{
				return ['status'=> 303, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
			
		}else{
			return ['status'=> 303, 'message'=> 'Invalid product id'];
		}
		
	}


	public function getBrands(){
		$q = $this->con->query("SELECT * FROM brands");
		$ar = [];
		if ($q && $q->num_rows > 0) {
			while($row = $q->fetch_assoc()) {
				$ar[] = $row;
			}
		}
		return ['status'=> 202, 'message'=> $ar];
	}

	public function addCategory($name){
		$name_esc = $this->con->real_escape_string($name);
		$q = $this->con->query("SELECT * FROM categories WHERE cat_title = '$name_esc' LIMIT 1");
		if ($q && $q->num_rows > 0) {
			return ['status'=> 303, 'message'=> 'Category already exists'];
		}else{
			$q = $this->con->query("INSERT INTO categories (cat_title) VALUES ('$name_esc')");
			if ($q) {
				return ['status'=> 202, 'message'=> 'New Category added Successfully'];
			}else{
				return ['status'=> 303, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
		}
	}

	public function getCategories(){
		$q = $this->con->query("SELECT * FROM categories");
		$ar = [];
		if ($q && $q->num_rows > 0) {
			while($row = $q->fetch_assoc()){
				$ar[] = $row;
			}
		}
		return ['status'=> 202, 'message'=> $ar];
	}

	public function deleteProduct($pid = null){
		if ($pid != null) {
			$pid_esc = $this->con->real_escape_string($pid);
			$q = $this->con->query("DELETE FROM products WHERE product_id = '$pid_esc'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Product removed from stocks'];
			}else{
				return ['status'=> 202, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Invalid product id'];
		}

	}

	public function deleteCategory($cid = null){
		if ($cid != null) {
			$cid_esc = $this->con->real_escape_string($cid);
			$q = $this->con->query("DELETE FROM categories WHERE cat_id = '$cid_esc'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Category removed'];
			}else{
				return ['status'=> 202, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Invalid cattegory id'];
		}

	}
	


	public function updateCategory($post = null){
		extract($post);
		if (!empty($cat_id) && !empty($e_cat_title)) {
			$cat_id_esc = $this->con->real_escape_string($cat_id);
			$e_cat_title_esc = $this->con->real_escape_string($e_cat_title);
			$q = $this->con->query("UPDATE categories SET cat_title = '$e_cat_title_esc' WHERE cat_id = '$cat_id_esc'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Category updated'];
			}else{
				return ['status'=> 202, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Invalid category id'];
		}

	}

	public function addBrand($name){
		$name_esc = $this->con->real_escape_string($name);
		$q = $this->con->query("SELECT * FROM brands WHERE brand_title = '$name_esc' LIMIT 1");
		if ($q && $q->num_rows > 0) {
			return ['status'=> 303, 'message'=> 'Brand already exists'];
		}else{
			$q = $this->con->query("INSERT INTO brands (brand_title) VALUES ('$name_esc')");
			if ($q) {
				return ['status'=> 202, 'message'=> 'New Brand added Successfully'];
			}else{
				return ['status'=> 303, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
		}
	}

	public function deleteBrand($bid = null){
		if ($bid != null) {
			$bid_esc = $this->con->real_escape_string($bid);
			$q = $this->con->query("DELETE FROM brands WHERE brand_id = '$bid_esc'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Brand removed'];
			}else{
				return ['status'=> 202, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Invalid brand id'];
		}

	}
	


	public function updateBrand($post = null){
		extract($post);
		if (!empty($brand_id) && !empty($e_brand_title)) {
			$brand_id_esc = $this->con->real_escape_string($brand_id);
			$e_brand_title_esc = $this->con->real_escape_string($e_brand_title);
			$q = $this->con->query("UPDATE brands SET brand_title = '$e_brand_title_esc' WHERE brand_id = '$brand_id_esc'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Brand updated'];
			}else{
				return ['status'=> 202, 'message'=> 'Failed to run query: ' . $this->con->error];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Invalid brand id'];
		}
	}

	// Method to process rental order without decreasing actual product quantity
	// Process rental order and track availability based on dates
	public function processRentalOrder($product_id, $quantity, $start_date, $end_date, $user_id) {
		// First check if enough quantity is available for the rental period
		$q = $this->con->query("SELECT product_qty FROM products 
			WHERE product_id = '".$this->con->real_escape_string($product_id)."'");
		if (!$q) {
			return ['status' => 303, 'message' => 'Database error: '.$this->con->error];
		}
		
		// Check if query returned any results
		if ($q->num_rows == 0) {
			return ['status' => 303, 'message' => 'Product not found'];
		}
		
		$product = $q->fetch_assoc();
		if (!$product) {
			return ['status' => 303, 'message' => 'Product not found'];
		}
		
		// Check availability for the requested period
		$availability_check = $this->checkAvailabilityForPeriod($product_id, $start_date, $end_date);
		if ($availability_check['status'] == 202) {
			$available_qty = $availability_check['message']['available_qty'];
			if ($available_qty < $quantity) {
				return ['status' => 303, 'message' => 'Not enough quantity available for the selected period. Available: ' . $available_qty];
			}
		} else {
			return $availability_check;
		}

		// Begin transaction
		$this->con->begin_transaction();

		try {
			// Build insert dynamically depending on available status column
			$cols = ['user_id', 'product_id', 'qty', 'trx_id', 'p_status', 'rental_start_date', 'rental_end_date'];
			$placeholders = ['?', '?', '?', '?', '?', '?', '?'];
			$types = 'iisisss'; // user_id (i), product_id (i), qty (i), trx_id (s), p_status (s), rental_start_date (s), rental_end_date (s)
			$params = [$user_id, $product_id, $quantity, uniqid(), 'completed', $start_date, $end_date];

			// If a rental/order status column exists, include it (set to 'active')
			if (!empty($this->status_col)) {
				$cols[] = $this->status_col;
				$placeholders[] = '?';
				$types .= 's';
				$params[] = 'active';
			}

			$sql = "INSERT INTO orders (`".implode('`,`', $cols)."`) VALUES (".implode(',', $placeholders).")";
			$stmt = $this->prepareAndBind($sql, $types, $params);
			if (!$stmt) {
				throw new Exception("Failed to prepare order insert: " . $this->con->error);
			}
			if (!$stmt->execute()) {
				throw new Exception("Failed to create order: " . $stmt->error);
			}
			$stmt->close();

			$this->con->commit();
			return ['status' => 202, 'message' => 'Rental order processed successfully'];
		} catch (Exception $e) {
			$this->con->rollback();
			return ['status' => 303, 'message' => $e->getMessage()];
		}
	}

	// Helper method to check availability for a specific period
	public function checkAvailabilityForPeriod($product_id, $start_date, $end_date) {
		// Get total quantity of the product
		$q = $this->con->query("SELECT product_qty FROM products WHERE product_id = '".$this->con->real_escape_string($product_id)."'");
		if (!$q) {
			return ['status' => 303, 'message' => 'Database error: '.$this->con->error];
		}
		
		// Check if query returned any results
		if ($q->num_rows == 0) {
			return ['status' => 303, 'message' => 'Product not found'];
		}
		
		$product = $q->fetch_assoc();
		$total_qty = $product['product_qty'];

		// Get number of rentals that overlap with the requested period
		$q = $this->con->query("SELECT SUM(qty) as rented_qty 
			FROM orders 
			WHERE product_id = '".$this->con->real_escape_string($product_id)."' 
			AND rental_status = 'active'
			AND rental_start_date <= '".$this->con->real_escape_string($end_date)."' 
			AND rental_end_date >= '".$this->con->real_escape_string($start_date)."'");
		
		if (!$q) {
			return ['status' => 303, 'message' => 'Database error: '.$this->con->error];
		}
		
		$rentals = $q->fetch_assoc();
		$rented_qty = $rentals['rented_qty'] ?? 0;

		$available_qty = $total_qty - $rented_qty;

		return [
			'status' => 202,
			'message' => [
				'total_qty' => $total_qty,
				'rented_qty' => $rented_qty,
				'available_qty' => $available_qty
			]
		];
	}

	// Complete rental by updating order status (no need to restore product quantity)
	public function completeRental($order_id) {
		// Begin transaction
		$this->con->begin_transaction();

		try {
			// Build select to retrieve order details. If status column exists, filter by it.
			if (!empty($this->status_col)) {
				$sql_select = "SELECT product_id, qty FROM orders WHERE order_id = ? AND `".$this->status_col."` = 'active' LIMIT 1";
			} else {
				// If no explicit status column exists, just select by order_id (no status check).
				$sql_select = "SELECT product_id, qty FROM orders WHERE order_id = ? LIMIT 1";
			}

			$stmt = $this->prepareAndBind($sql_select, 'i', [$order_id]);
			if (!$stmt) {
				throw new Exception("Failed to prepare order select: " . $this->con->error);
			}
			$stmt->execute();
			$result = $stmt->get_result();
			if ($result->num_rows == 0) {
				throw new Exception("Order not found or already completed");
			}
			$order = $result->fetch_assoc();
			$stmt->close();

			// Update order status if status column exists
			if (!empty($this->status_col)) {
				$sql_update_status = "UPDATE orders SET `".$this->status_col."` = 'completed' WHERE order_id = ?";
				$stmt2 = $this->prepareAndBind($sql_update_status, 'i', [$order_id]);
				if (!$stmt2) {
					throw new Exception("Failed to prepare status update: " . $this->con->error);
				}
				if (!$stmt2->execute()) {
					throw new Exception("Failed to update order status: " . $stmt2->error);
				}
				$stmt2->close();
			} else {
				// If no status column, update the p_status column
				$sql_update_status = "UPDATE orders SET p_status = 'completed' WHERE order_id = ?";
				$stmt2 = $this->prepareAndBind($sql_update_status, 'i', [$order_id]);
				if (!$stmt2) {
					throw new Exception("Failed to prepare status update: " . $this->con->error);
				}
				if (!$stmt2->execute()) {
					throw new Exception("Failed to update order status: " . $stmt2->error);
				}
				$stmt2->close();
			}

			$this->con->commit();
			return ['status' => 202, 'message' => 'Rental completed successfully'];
		} catch (Exception $e) {
			$this->con->rollback();
			return ['status' => 303, 'message' => $e->getMessage()];
		}
	}

	public function getEquipmentAvailability() {
		try {
			// Get the logged in vendor/admin ID
			$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
			
			$current_date = date('Y-m-d');

			// Build condition snippet depending on whether a status column exists
			$status_sub_cond = '';
			$status_condition_upcoming = '';
			if (!empty($this->status_col)) {
				$col = $this->status_col;
				$status_sub_cond = "AND o.`$col` = 'active'";
				$status_condition_upcoming = "AND o.`$col` = 'active'";
			}
			
			$query = "SELECT 
				p.product_id,
				p.product_title,
				p.product_qty as total_quantity,
				COALESCE((
					SELECT COUNT(*) 
					FROM orders o 
					WHERE o.product_id = p.product_id 
					{$status_sub_cond}
					AND o.rental_start_date <= ? 
					AND o.rental_end_date >= ?
				), 0) as currently_rented,
				COALESCE((
					SELECT COUNT(*) 
					FROM orders o 
					WHERE o.product_id = p.product_id 
					{$status_condition_upcoming}
					AND o.rental_start_date > ?
				), 0) as upcoming_rentals,
				(p.product_qty - COALESCE((
					SELECT COUNT(*) 
					FROM orders o 
					WHERE o.product_id = p.product_id 
					{$status_sub_cond}
					AND o.rental_start_date <= ? 
					AND o.rental_end_date >= ?
				), 0)) as available_quantity,
				c.cat_title,
				b.brand_title
			FROM products p
			JOIN categories c ON c.cat_id = p.product_cat
			JOIN brands b ON b.brand_id = p.product_brand
			WHERE p.vendor_id = ?
			ORDER BY p.product_title ASC";
			
			// bind parameters: current_date appears 5 times and vendor_id once
			$stmt = $this->prepareAndBind($query, "sssssi", [
				$current_date, 
				$current_date, 
				$current_date, 
				$current_date, 
				$current_date, 
				$vendor_id
			]);
			if (!$stmt) {
				error_log("prepare() failed in getEquipmentAvailability: " . $this->con->error);
				return ['status' => 303, 'message' => 'Database error: ' . $this->con->error];
			}
			
			$stmt->execute();
			$result = $stmt->get_result();
			$stmt->close();
			
			$availability = [];
			if ($result && $result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					// Ensure non-negative available quantity
					$row['available_quantity'] = max(0, (int)$row['available_quantity']);
					$availability[] = $row;
				}
				return ['status' => 202, 'message' => $availability];
			}
			
			return ['status' => 202, 'message' => []];
			
		} catch (Exception $e) {
			error_log("Error in getEquipmentAvailability: " . $e->getMessage());
			return ['status' => 303, 'message' => 'Error retrieving equipment availability'];
		}
	}

	public function getRentalSchedule() {
		try {
			// Get the logged in vendor/admin ID
			$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
			
			$current_date = date('Y-m-d');

			// If we have a status column, select it and filter by active. Otherwise return NULL as rental_status and don't filter by status.
			if (!empty($this->status_col)) {
				$col = $this->status_col;
				$status_select = "o.`$col` as rental_status";
				$status_where = "AND o.`$col` = 'active'";
			} else {
				$status_select = "NULL as rental_status";
				$status_where = "";
			}
			
			$query = "SELECT 
				o.order_id,
				p.product_title,
				o.qty,
				DATE_FORMAT(o.rental_start_date, '%Y-%m-%d') as rental_start_date,
				DATE_FORMAT(o.rental_end_date, '%Y-%m-%d') as rental_end_date,
				{$status_select},
				u.first_name,
				u.last_name,
				u.mobile
			FROM orders o
			JOIN products p ON p.product_id = o.product_id
			JOIN user_info u ON u.user_id = o.user_id
			WHERE p.vendor_id = ?
			{$status_where}
			AND o.rental_end_date >= ?
			ORDER BY o.rental_start_date ASC";
			
			$stmt = $this->prepareAndBind($query, "is", [$vendor_id, $current_date]);
			if (!$stmt) {
				error_log("prepare() failed in getRentalSchedule: " . $this->con->error);
				return ['status' => 303, 'message' => 'Database error: ' . $this->con->error];
			}
			
			$stmt->execute();
			$result = $stmt->get_result();
			$stmt->close();
			
			$schedule = [];
			if ($result && $result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$schedule[] = $row;
				}
				return ['status' => 202, 'message' => $schedule];
			}
			
			return ['status' => 202, 'message' => []];
			
		} catch (Exception $e) {
			error_log("Error in getRentalSchedule: " . $e->getMessage());
			return ['status' => 303, 'message' => 'Error retrieving rental schedule'];
		}
	}

	public function checkAvailability($product_id, $start_date, $end_date) {
		// Get total quantity of the product
		$q = $this->con->query("SELECT product_qty FROM products WHERE product_id = '".$this->con->real_escape_string($product_id)."'");
		if (!$q) {
			return ['status' => 303, 'message' => 'Database error: '.$this->con->error];
		}
		$product = $q->fetch_assoc();
		$total_qty = $product['product_qty'];

		// Get number of rentals for the given period
		$q = $this->con->query("SELECT COUNT(*) as rented_qty 
			FROM cart 
			WHERE p_id = '".$this->con->real_escape_string($product_id)."' 
			AND rental_start_date <= '".$this->con->real_escape_string($end_date)."' 
			AND rental_end_date >= '".$this->con->real_escape_string($start_date)."'");
		$rentals = $q->fetch_assoc();
		$rented_qty = $rentals['rented_qty'];

		$available_qty = $total_qty - $rented_qty;

		return [
			'status' => 202,
			'message' => [
				'total_qty' => $total_qty,
				'rented_qty' => $rented_qty,
				'available_qty' => $available_qty
			]
		];
	}

	public function updateAvailability() {
		// Update availability based on current date
		$current_date = date('Y-m-d');
		
		// Get all products
		$q = $this->con->query("SELECT product_id, product_qty FROM products");
		if ($q) {
			while($product = $q->fetch_assoc()) {
				$pid = $product['product_id'];
				
				// Count current rentals
				$rq = $this->con->query("SELECT COUNT(*) as rented 
					FROM cart 
					WHERE p_id = '".$this->con->real_escape_string($pid)."' 
					AND rental_start_date <= '".$this->con->real_escape_string($current_date)."' 
					AND rental_end_date >= '".$this->con->real_escape_string($current_date)."'");
				$rentals = $rq->fetch_assoc();
				
				// Update available quantity
				$available = $product['product_qty'] - ($rentals['rented'] ?? 0);
				$this->con->query("UPDATE products 
					SET available_qty = '".$this->con->real_escape_string($available)."' 
					WHERE product_id = '".$this->con->real_escape_string($pid)."'");
			}
		}
		return ['status'=> 202, 'message'=> 'Availability updated'];
	}

	// New method to get equipment availability based on specific dates
	public function getEquipmentAvailabilityByDate($date = null) {
		try {
			// Get the logged in vendor/admin ID
			$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
			
			// Use provided date or current date
			$check_date = $date ? $date : date('Y-m-d');

			// Build condition snippet depending on whether a status column exists
			$status_sub_cond = '';
			if (!empty($this->status_col)) {
				$col = $this->status_col;
				$status_sub_cond = "AND o.`$col` = 'active'";
			}
			
			$query = "SELECT 
				p.product_id,
				p.product_title,
				p.product_qty as total_quantity,
				COALESCE((
					SELECT COUNT(*) 
					FROM orders o 
					WHERE o.product_id = p.product_id 
					{$status_sub_cond}
					AND o.rental_start_date <= ? 
					AND o.rental_end_date >= ?
				), 0) as rented_on_date,
				(p.product_qty - COALESCE((
					SELECT COUNT(*) 
					FROM orders o 
					WHERE o.product_id = p.product_id 
					{$status_sub_cond}
					AND o.rental_start_date <= ? 
					AND o.rental_end_date >= ?
				), 0)) as available_on_date,
				c.cat_title,
				b.brand_title
			FROM products p
			JOIN categories c ON c.cat_id = p.product_cat
			JOIN brands b ON b.brand_id = p.product_brand
			WHERE p.vendor_id = ?
			ORDER BY p.product_title ASC";
			
			// bind parameters: check_date appears 4 times and vendor_id once
			$stmt = $this->prepareAndBind($query, "sss si", [
				$check_date, 
				$check_date, 
				$check_date, 
				$check_date, 
				$vendor_id
			]);
			if (!$stmt) {
				error_log("prepare() failed in getEquipmentAvailabilityByDate: " . $this->con->error);
				return ['status' => 303, 'message' => 'Database error: ' . $this->con->error];
			}
			
			$stmt->execute();
			$result = $stmt->get_result();
			$stmt->close();
			
			$availability = [];
			if ($result && $result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					// Ensure non-negative available quantity
					$row['available_on_date'] = max(0, (int)$row['available_on_date']);
					$availability[] = $row;
				}
				return ['status' => 202, 'message' => $availability];
			}
			
			return ['status' => 202, 'message' => []];
			
		} catch (Exception $e) {
			error_log("Error in getEquipmentAvailabilityByDate: " . $e->getMessage());
			return ['status' => 303, 'message' => 'Error retrieving equipment availability'];
		}
	}

	// New method to automatically adjust equipment availability based on rental dates
	public function autoAdjustEquipmentAvailability() {
		try {
			// Get the logged in vendor/admin ID
			$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
			
			$current_date = date('Y-m-d');

			// Build condition snippet depending on whether a status column exists
			$status_cond = '';
			if (!empty($this->status_col)) {
				$col = $this->status_col;
				$status_cond = "AND o.`$col` = 'active'";
			}

			// Get all products for this vendor
			$query = "SELECT product_id, product_title, product_qty FROM products WHERE vendor_id = ?";
			$stmt = $this->prepareAndBind($query, "i", [$vendor_id]);
			if (!$stmt) {
				return ['status' => 303, 'message' => 'Database error: ' . $this->con->error];
			}
			
			$stmt->execute();
			$result = $stmt->get_result();
			
			$updates = [];
			while($product = $result->fetch_assoc()) {
				$pid = $product['product_id'];
				$total_qty = $product['product_qty'];
				
				// Count rentals that are currently active (rental period includes today)
				$rental_query = "SELECT COUNT(*) as rented_qty 
					FROM orders o 
					WHERE o.product_id = ? 
					AND o.rental_start_date <= ? 
					AND o.rental_end_date >= ?
					{$status_cond}";
				
				$rental_stmt = $this->prepareAndBind($rental_query, "iss", [$pid, $current_date, $current_date]);
				if ($rental_stmt) {
					$rental_stmt->execute();
					$rental_result = $rental_stmt->get_result();
					$rentals = $rental_result->fetch_assoc();
					$rented_qty = $rentals['rented_qty'] ?? 0;
					$rental_stmt->close();
					
					// Calculate available quantity
					$available_qty = $total_qty - $rented_qty;
					
					// Store for reporting
					$updates[] = [
						'product_id' => $pid,
						'product_title' => $product['product_title'],
						'total_qty' => $total_qty,
						'rented_qty' => $rented_qty,
						'available_qty' => max(0, $available_qty)
					];
				}
			}
			$stmt->close();
			
			return ['status' => 202, 'message' => $updates];
			
		} catch (Exception $e) {
			error_log("Error in autoAdjustEquipmentAvailability: " . $e->getMessage());
			return ['status' => 303, 'message' => 'Error adjusting equipment availability'];
		}
	}

} // end class


// -------------------- endpoint handlers (kept largely the same as original) --------------------

if (isset($_POST['GET_PRODUCT'])) {
	if (isset($_SESSION['admin_id'])) {
		$p = new Products();
		echo json_encode($p->getProducts());
		exit();
	}
}


if (isset($_POST['add_product'])) {

	extract($_POST);
	if (!empty($product_name) 
	&& !empty($brand_id) 
	&& !empty($category_id)
	&& !empty($product_desc)
	&& !empty($product_qty)
	&& !empty($product_price)
	&& !empty($product_keywords)
	&& !empty($_FILES['product_image']['name'])) {
		

		$p = new Products();
		$result = $p->addProduct($product_name,
								$brand_id,
								$category_id,
								$product_desc,
								$product_qty,
								$product_price,
								$product_keywords,
								$_FILES['product_image']);
		
		header("Content-type: application/json");
		echo json_encode($result);
		http_response_code($result['status']);
		exit();


	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Empty fields']);
		exit();
	}

}

if (isset($_POST['edit_product'])) {

	extract($_POST);
	if (!empty($pid)
	&& !empty($e_product_name) 
	&& !empty($e_brand_id) 
	&& !empty($e_category_id)
	&& !empty($e_product_desc)
	&& !empty($e_product_qty)
	&& !empty($e_product_price)
	&& !empty($e_product_keywords) ) {
		
		$p = new Products();

		if (isset($_FILES['e_product_image']['name']) 
			&& !empty($_FILES['e_product_image']['name'])) {
			$result = $p->editProductWithImage($pid,
								$e_product_name,
								$e_brand_id,
								$e_category_id,
								$e_product_desc,
								$e_product_qty,
								$e_product_price,
								$e_product_keywords,
								$_FILES['e_product_image']);
		}else{
			$result = $p->editProductWithoutImage($pid,
								$e_product_name,
								$e_brand_id,
								$e_category_id,
								$e_product_desc,
								$e_product_qty,
								$e_product_price,
								$e_product_keywords);
		}

		echo json_encode($result);
		exit();


	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Empty fields']);
		exit();
	}

}

if (isset($_POST['GET_BRAND'])) {
	$p = new Products();
	echo json_encode($p->getBrands());
	exit();
	
}

if (isset($_POST['add_category'])) {
	if (isset($_SESSION['admin_id'])) {
		$cat_title = $_POST['cat_title'];
		if (!empty($cat_title)) {
			$p = new Products();
			echo json_encode($p->addCategory($cat_title));
		}else{
			echo json_encode(['status'=> 303, 'message'=> 'Empty fields']);
		}
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Session Error']);
	}
}

if (isset($_POST['GET_CATEGORIES'])) {
	$p = new Products();
	echo json_encode($p->getCategories());
	exit();
	
}

if (isset($_POST['DELETE_PRODUCT'])) {
	$p = new Products();
	if (isset($_SESSION['admin_id'])) {
		if(!empty($_POST['pid'])){
			$pid = $_POST['pid'];
			echo json_encode($p->deleteProduct($pid));
			exit();
		}else{
			echo json_encode(['status'=> 303, 'message'=> 'Invalid product id']);
			exit();
		}
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Invalid Session']);
	}
}

if (isset($_POST['DELETE_CATEGORY'])) {
	if (!empty($_POST['cid'])) {
		$p = new Products();
		echo json_encode($p->deleteCategory($_POST['cid']));
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Invalid details']);
		exit();
	}
}

if (isset($_POST['edit_category'])) {
	if (!empty($_POST['cat_id'])) {
		$p = new Products();
		echo json_encode($p->updateCategory($_POST));
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Invalid details']);
		exit();
	}
}

if (isset($_POST['add_brand'])) {
	if (isset($_SESSION['admin_id'])) {
		$brand_title = $_POST['brand_title'];
		if (!empty($brand_title)) {
			$p = new Products();
			echo json_encode($p->addBrand($brand_title));
		}else{
			echo json_encode(['status'=> 303, 'message'=> 'Empty fields']);
		}
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Session Error']);
	}
}

if (isset($_POST['DELETE_BRAND'])) {
	if (!empty($_POST['bid'])) {
		$p = new Products();
		echo json_encode($p->deleteBrand($_POST['bid']));
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Invalid details']);
		exit();
	}
}

if (isset($_POST['edit_brand'])) {
	if (!empty($_POST['brand_id'])) {
		$p = new Products();
		echo json_encode($p->updateBrand($_POST));
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Invalid details']);
		exit();
	}
}

// Get equipment availability status
if (isset($_POST['get_availability'])) {
	if (isset($_SESSION['admin_id'])) {
		$p = new Products();
		echo json_encode($p->getEquipmentAvailability());
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Session Error']);
		exit();
	}
}

// Get rental schedule
if (isset($_POST['get_rental_schedule'])) {
	if (isset($_SESSION['admin_id'])) {
		$p = new Products();
		echo json_encode($p->getRentalSchedule());
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Session Error']);
		exit();
	}
}

// Handle new rental order
if (isset($_POST['process_rental'])) {
	if (!empty($_POST['product_id']) && 
		isset($_POST['quantity']) && 
		!empty($_POST['start_date']) && 
		!empty($_POST['end_date']) && 
		!empty($_POST['user_id'])) {
		
		$p = new Products();
		echo json_encode($p->processRentalOrder(
			$_POST['product_id'],
			$_POST['quantity'],
			$_POST['start_date'],
			$_POST['end_date'],
			$_POST['user_id']
		));
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Missing rental details']);
		exit();
	}
}

// Handle rental completion
if (isset($_POST['complete_rental'])) {
	if (!empty($_POST['order_id'])) {
		$p = new Products();
		echo json_encode($p->completeRental($_POST['order_id']));
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Missing order ID']);
		exit();
	}
}

// Check availability for a given date range
if (isset($_POST['check_availability'])) {
	if (!empty($_POST['product_id']) && !empty($_POST['start_date']) && !empty($_POST['end_date'])) {
		$p = new Products();
		echo json_encode($p->checkAvailability(
			$_POST['product_id'],
			$_POST['start_date'],
			$_POST['end_date']
		));
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Missing required fields']);
		exit();
	}
}

if (isset($_POST['update_availability'])) {
	$p = new Products();
	echo json_encode($p->updateAvailability());
	exit();
}

// New endpoint for getting availability by specific date
if (isset($_POST['get_availability_by_date'])) {
	if (isset($_SESSION['admin_id'])) {
		$date = isset($_POST['date']) ? $_POST['date'] : null;
		$p = new Products();
		echo json_encode($p->getEquipmentAvailabilityByDate($date));
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Session Error']);
		exit();
	}
}

// New endpoint for automatically adjusting equipment availability
if (isset($_POST['auto_adjust_availability'])) {
	if (isset($_SESSION['admin_id'])) {
		$p = new Products();
		echo json_encode($p->autoAdjustEquipmentAvailability());
		exit();
	} else {
		echo json_encode(['status'=> 303, 'message'=> 'Session Error']);
		exit();
	}
}

?>