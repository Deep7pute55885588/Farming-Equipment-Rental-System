<?php 
session_start();
/**
 * 
 */
class Customers
{
	
	private $con;

	function __construct()
	{
		include_once("Database.php");
		$db = new Database();
		$this->con = $db->connect();
	}

	public function getCustomers(){
		// Get the logged in vendor/admin ID
		$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
		
		// Only get customers who have rented this vendor's equipment
		$query = $this->con->query("SELECT DISTINCT 
			u.user_id, 
			u.first_name, 
			u.last_name, 
			u.email, 
			u.mobile, 
			u.address1, 
			u.address2 
		FROM user_info u 
		INNER JOIN orders o ON u.user_id = o.user_id 
		INNER JOIN products p ON o.product_id = p.product_id 
		WHERE p.vendor_id = $vendor_id");
		
		$ar = [];
		if (@$query->num_rows > 0) {
			while ($row = $query->fetch_assoc()) {
				$ar[] = $row;
			}
			return ['status'=> 202, 'message'=> $ar];
		}
		return ['status'=> 303, 'message'=> 'no customer data'];
	}


	public function getCustomersOrder(){
		// Get the logged in vendor/admin ID
		$vendor_id = isset($_SESSION['admin_id']) ? $_SESSION['admin_id'] : 0;
		
		// include rental dates and product price so we can compute duration and total
		$query = $this->con->query("SELECT 
			o.order_id, 
			o.product_id,
			o.qty, 
			o.trx_id, 
			o.p_status,
			o.rental_start_date,
			o.rental_end_date,
			p.product_title,
			p.product_image,
			p.product_price,
			u.first_name,
			u.last_name,
			u.email,
			u.mobile,
			u.address1,
			u.address2
		FROM orders o 
		JOIN products p ON o.product_id = p.product_id
		JOIN user_info u ON o.user_id = u.user_id
		WHERE p.vendor_id = $vendor_id");
		
		$ar = [];
		
			if (@$query->num_rows > 0 ) {
				while ($row = $query->fetch_assoc() ) {
					// compute duration hours and total cost
					$rstart = $row['rental_start_date'];
					$rend = $row['rental_end_date'];
					$price = isset($row['product_price']) ? floatval($row['product_price']) : 0;
					$qty = isset($row['qty']) ? intval($row['qty']) : 1;
					if (!empty($rstart) && !empty($rend)) {
						$hours = ceil((strtotime($rend) - strtotime($rstart)) / 3600);
						if ($hours < 1) $hours = 1;
						$total = $price * $hours;
					} else {
						$hours = 0;
						$total = $price * $qty;
					}
					$row['duration_hours'] = $hours;
					$row['rate_per_hour'] = $price;
					$row['total_cost'] = $total;
					$ar[] = $row;
				}
				return ['status'=> 202, 'message'=> $ar];
			}
		return ['status'=> 303, 'message'=> 'no orders yet'];
		
	}
	

}


/*$c = new Customers();
echo "<pre>";
print_r($c->getCustomers());
exit();*/

if (isset($_POST["GET_CUSTOMERS"])) {
	if (isset($_SESSION['admin_id'])) {
		$c = new Customers();
		echo json_encode($c->getCustomers());
		exit();
	}
}

if (isset($_POST["GET_CUSTOMER_ORDERS"])) {
	if (isset($_SESSION['admin_id'])) {
		$c = new Customers();
		echo json_encode($c->getCustomersOrder());
		exit();
	}
}


?>