<?php

// Start session only if not already started to avoid duplicate-session notices
if (session_status() == PHP_SESSION_NONE) {
	session_start();
}

/**
 * 
 */
class Admin
{
	
	private $con;

	function __construct()
	{
		include_once("Database.php");
		$db = new Database();
		$this->con = $db->connect();
	}

	public function getAdminDashboard(){
		if(!isset($_SESSION['admin_id'])) {
			return ['status'=> 303, 'message'=> 'Not logged in'];
		}

		$admin_id = $_SESSION['admin_id'];
		
		// Get admin information
		$query = $this->con->query("SELECT id, name, email, phone, address, city, state, is_active, 
			DATE_FORMAT(registration_date, '%d %M %Y') as registration_date 
			FROM admin WHERE id = $admin_id");
		
		if ($query->num_rows > 0) {
			$data = $query->fetch_assoc();
			
			// Get total products
			$products_query = $this->con->query("SELECT COUNT(*) as total_products 
				FROM products WHERE vendor_id = $admin_id");
			$products_data = $products_query->fetch_assoc();
			$data['total_products'] = $products_data['total_products'];
			
			// Get orders statistics
			$orders_query = $this->con->query("SELECT 
				COUNT(DISTINCT o.order_id) as total_orders,
				COUNT(DISTINCT CASE WHEN o.p_status = 'pending' THEN o.order_id END) as active_orders
				FROM orders o 
				JOIN products p ON o.product_id = p.product_id 
				WHERE p.vendor_id = $admin_id");
			$orders_data = $orders_query->fetch_assoc();
			$data['total_orders'] = $orders_data['total_orders'];
			$data['active_orders'] = $orders_data['active_orders'];
			
			// Get total customers who ordered this vendor's products
			$customers_query = $this->con->query("SELECT COUNT(DISTINCT o.user_id) as total_customers 
				FROM orders o 
				JOIN products p ON o.product_id = p.product_id 
				WHERE p.vendor_id = $admin_id");
			$customers_data = $customers_query->fetch_assoc();
			$data['total_customers'] = $customers_data['total_customers'];
			
			return ['status'=> 202, 'message'=> $data];
		}
		
		return ['status'=> 303, 'message'=> 'Admin not found'];
	}

	public function updateAdminProfile($name, $email, $phone, $address, $city, $state, $password = null) {
		if(!isset($_SESSION['admin_id'])) {
			return ['status'=> 303, 'message'=> 'Not logged in'];
		}

		$admin_id = $_SESSION['admin_id'];
		
		if($password) {
			$hashed_password = password_hash($password, PASSWORD_DEFAULT);
			$query = $this->con->prepare("UPDATE admin SET 
				name=?, 
				email=?, 
				phone=?, 
				address=?, 
				city=?, 
				state=?,
				password=? 
				WHERE id=?");
			$query->bind_param("sssssssi", $name, $email, $phone, $address, $city, $state, $hashed_password, $admin_id);
		} else {
			$query = $this->con->prepare("UPDATE admin SET 
				name=?, 
				email=?, 
				phone=?, 
				address=?, 
				city=?, 
				state=?
				WHERE id=?");
			$query->bind_param("ssssssi", $name, $email, $phone, $address, $city, $state, $admin_id);
		}

		if($query->execute()) {
			return ['status'=> 202, 'message'=> 'Profile updated successfully'];
		}
		
		return ['status'=> 303, 'message'=> 'Failed to update profile'];
	}

	public function getAdminProfile() {
		if(!isset($_SESSION['admin_id'])) {
			return ['status'=> 303, 'message'=> 'Not logged in'];
		}

		$admin_id = $_SESSION['admin_id'];
		$query = $this->con->query("SELECT id, name, email, is_active FROM admin WHERE id = $admin_id");
		
		if ($query->num_rows > 0) {
			$row = $query->fetch_assoc();
			return ['status'=> 202, 'message'=> $row];
		}
		
		return ['status'=> 303, 'message'=> 'Profile not found'];
	}
}

if (isset($_POST['GET_ADMIN_DASHBOARD'])) {
	$a = new Admin();
	echo json_encode($a->getAdminDashboard());
	exit();
}

if (isset($_POST['GET_ADMIN'])) {
	$a = new Admin();
	echo json_encode($a->getAdminList());
	exit();
}

if (isset($_POST['GET_ADMIN_PROFILE'])) {
	$a = new Admin();
	echo json_encode($a->getAdminProfile());
	exit();
}

if (isset($_POST['UPDATE_ADMIN_PROFILE'])) {
	$a = new Admin();
	$name = isset($_POST['name']) ? $_POST['name'] : '';
	$email = isset($_POST['email']) ? $_POST['email'] : '';
	$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
	$address = isset($_POST['address']) ? $_POST['address'] : '';
	$city = isset($_POST['city']) ? $_POST['city'] : '';
	$state = isset($_POST['state']) ? $_POST['state'] : '';
	$password = isset($_POST['password']) && !empty($_POST['password']) ? $_POST['password'] : null;
	echo json_encode($a->updateAdminProfile($name, $email, $phone, $address, $city, $state, $password));
	exit();
}

if (isset($_POST['GET_ADMIN_STATS'])) {
	if(!isset($_SESSION['admin_id'])) {
		echo json_encode(['status'=> 303, 'message'=> 'Not logged in']);
		exit();
	}

	$admin_id = $_SESSION['admin_id'];
	$a = new Admin();

	// Get total products for this admin
	$products_query = $a->con->query("SELECT COUNT(*) as total_products FROM products WHERE vendor_id = $admin_id");
	$products_row = $products_query->fetch_assoc();
	$total_products = $products_row['total_products'];

	// Get total orders for this admin's products
	$orders_query = $a->con->query("SELECT COUNT(DISTINCT o.order_id) as total_orders 
		FROM orders o 
		JOIN products p ON o.product_id = p.product_id 
		WHERE p.vendor_id = $admin_id");
	$orders_row = $orders_query->fetch_assoc();
	$total_orders = $orders_row['total_orders'];

	echo json_encode([
		'status'=> 202, 
		'message'=> [
			'total_products' => $total_products,
			'total_orders' => $total_orders
		]
	]);
	exit();
}

?>