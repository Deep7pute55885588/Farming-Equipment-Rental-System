<?php session_start(); ?>
<?php include_once("./templates/top.php"); ?>
<?php include_once("./templates/navbar.php"); ?>
<div class="container-fluid">
  <div class="row">
    
    <?php include "./templates/sidebar.php"; ?>

    <div class="row">
      <div class="col-10">
        <h2>My Profile</h2>
      </div>
    </div>
    
    <div class="container">
      <div class="row">
        <div class="col-md-6 mx-auto">
          <div class="card">
            <div class="card-header">
              <h4>Admin Profile Information</h4>
            </div>
            <div class="card-body">
              <form id="admin-profile-form">
                <div class="form-group">
                  <label>ID</label>
                  <input type="text" class="form-control" id="admin-id" readonly>
                </div>
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="name" class="form-control" id="admin-name" required>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" id="admin-email" required>
                </div>
                <div class="form-group">
                  <label>Account Status</label>
                  <input type="text" class="form-control" id="admin-status" readonly>
                </div>
                <div class="form-group">
                  <label>New Password (leave empty to keep current)</label>
                  <input type="password" name="password" class="form-control" placeholder="Enter new password">
                </div>
                <div class="form-group">
                  <label>Confirm New Password</label>
                  <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password">
                </div>
                <input type="hidden" name="UPDATE_ADMIN_PROFILE" value="1">
                <button type="button" class="btn btn-primary update-profile">Update Profile</button>
              </form>
              <div class="message mt-3"></div>
            </div>
          </div>

          <!-- Statistics Card -->
          
        </div>
      </div>
    </div>

  </div>
</div>

<?php include_once("./templates/footer.php"); ?>

<script type="text/javascript" src="./js/admin_profile.js"></script>