<?php 
session_start();  
if (!isset($_SESSION['admin_id'])) {
  header("location:login.php");
}

include "./templates/top.php"; 

?>
 
<?php include "./templates/navbar.php"; ?>

<div class="container-fluid">
  <div class="row">
    
      <?php include "./templates/sidebar.php"; ?>
      <?php
      // Server-side fetch admin dashboard data to ensure values are visible even if AJAX fails
      include_once __DIR__ . '/classes/Admin.php';
      $adminData = ['name'=>'Not provided','email'=>'Not provided','phone'=>'Not provided','address'=>'Not provided','city'=>'Not provided','state'=>'Not provided','registration_date'=>'Not provided','is_active'=>'0','total_products'=>0,'active_orders'=>0,'total_orders'=>0,'total_customers'=>0];
      $a = new Admin();
      $resp = $a->getAdminDashboard();
      if ($resp['status'] == 202) {
        $adminData = array_merge($adminData, $resp['message']);
      }
      ?>

      <div class="row mt-4">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h2>My Information</h2>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="admin-info">
                    <h4>Personal Details</h4>
                    <table class="table">
                      <tr>
                        <th>Name:</th>
                        <td id="admin-name"><?php echo htmlspecialchars($adminData['name']); ?></td>
                      </tr>
                      <tr>
                        <th>Email:</th>
                        <td id="admin-email"><?php echo htmlspecialchars($adminData['email']); ?></td>
                      </tr>
              
                      <tr>
                        <th>Registration Date:</th>
                        <td id="admin-reg-date"><?php echo htmlspecialchars($adminData['registration_date']); ?></td>
                      </tr>
                      <tr>
                        <th>Account Status:</th>
                        <td id="admin-status">Active</td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="admin-stats">
                    <h4>Business Summary</h4>
                    <table class="table">
                      <tr>
                        <th>Total Products:</th>
                        <td id="total-products"><?php echo intval($adminData['total_products']); ?></td>
                      </tr>
                      <tr>
                        <th>Total Orders:</th>
                        <td id="total-orders"><?php echo intval($adminData['total_orders']); ?></td>
                      </tr>
                      <tr>
                        <th>Total Customers:</th>
                        <td id="total-customers"><?php echo intval($adminData['total_customers']); ?></td>
                      </tr>
                    </table>
                    <div class="text-right">
                      <a href="profile.php" class="btn btn-primary">Edit Profile</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<?php include "./templates/footer.php"; ?>

<script type="text/javascript" src="./js/admin.js"></script>
