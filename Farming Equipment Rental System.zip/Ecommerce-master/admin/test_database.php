<?php
include "../db.php";

echo "<h2>Database Structure Test</h2>";

// Test orders table structure
echo "<h3>Orders Table Columns</h3>";
$result = mysqli_query($con, "SHOW COLUMNS FROM `orders`");
if ($result) {
    echo "<ul>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<li>" . $row['Field'] . " (" . $row['Type'] . ")</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Error: " . mysqli_error($con) . "</p>";
}

// Test products table structure
echo "<h3>Products Table Columns</h3>";
$result = mysqli_query($con, "SHOW COLUMNS FROM `products`");
if ($result) {
    echo "<ul>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<li>" . $row['Field'] . " (" . $row['Type'] . ")</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Error: " . mysqli_error($con) . "</p>";
}

mysqli_close($con);
?>