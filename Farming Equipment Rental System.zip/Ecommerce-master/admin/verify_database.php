<?php
include "../db.php";

echo "<h2>Database Verification</h2>";

// Test if required columns exist in orders table
$required_columns = ['rental_start_date', 'rental_end_date', 'rental_status'];
$missing_columns = [];

foreach ($required_columns as $column) {
    $check_column = "SHOW COLUMNS FROM `orders` LIKE '$column'";
    $result = mysqli_query($con, $check_column);
    
    if (mysqli_num_rows($result) == 0) {
        $missing_columns[] = $column;
    }
}

if (empty($missing_columns)) {
    echo "<p>✓ All required columns exist in the orders table</p>";
    
    // Show the structure of the orders table
    echo "<h3>Orders Table Structure</h3>";
    $result = mysqli_query($con, "SHOW COLUMNS FROM `orders`");
    if ($result) {
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Field'] . "</td>";
            echo "<td>" . $row['Type'] . "</td>";
            echo "<td>" . $row['Null'] . "</td>";
            echo "<td>" . $row['Key'] . "</td>";
            echo "<td>" . $row['Default'] . "</td>";
            echo "<td>" . $row['Extra'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} else {
    echo "<p>✗ Missing columns: " . implode(', ', $missing_columns) . "</p>";
    echo "<p>Please run the update_database.php script to add missing columns.</p>";
}

// Test a simple insert to verify the columns work
echo "<h3>Testing Column Functionality</h3>";
$test_query = "INSERT INTO `orders` (`user_id`, `product_id`, `qty`, `trx_id`, `p_status`, `rental_start_date`, `rental_end_date`, `rental_status`) 
               VALUES (1, 1, 1, 'TEST123', 'completed', '2025-11-10', '2025-11-15', 'active') 
               ON DUPLICATE KEY UPDATE `trx_id` = 'TEST123'";

if (mysqli_query($con, $test_query)) {
    echo "<p>✓ Columns are working properly</p>";
    
    // Clean up test record
    mysqli_query($con, "DELETE FROM `orders` WHERE `trx_id` = 'TEST123'");
} else {
    echo "<p>✗ Error testing columns: " . mysqli_error($con) . "</p>";
}

mysqli_close($con);
?>