<?php
session_start();
$_SESSION['admin_id'] = 1; // Simulate admin login for testing

include_once "classes/Products.php";

// Test the equipment availability functionality
$products = new Products();

echo "<h2>Verifying Equipment Availability System</h2>";

// Test 1: Check current availability
echo "<h3>Current Availability</h3>";
$availability = $products->getEquipmentAvailability();
if ($availability['status'] == 202) {
    echo "<p>✓ Equipment availability check successful</p>";
    echo "<pre>" . print_r($availability['message'], true) . "</pre>";
} else {
    echo "<p>✗ Equipment availability check failed: " . $availability['message'] . "</p>";
}

// Test 2: Check availability for a specific date
echo "<h3>Availability for Tomorrow</h3>";
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$availability_tomorrow = $products->getEquipmentAvailabilityByDate($tomorrow);
if ($availability_tomorrow['status'] == 202) {
    echo "<p>✓ Date-specific availability check successful</p>";
    echo "<pre>" . print_r($availability_tomorrow['message'], true) . "</pre>";
} else {
    echo "<p>✗ Date-specific availability check failed: " . $availability_tomorrow['message'] . "</p>";
}

// Test 3: Check rental schedule
echo "<h3>Current Rental Schedule</h3>";
$schedule = $products->getRentalSchedule();
if ($schedule['status'] == 202) {
    echo "<p>✓ Rental schedule check successful</p>";
    echo "<pre>" . print_r($schedule['message'], true) . "</pre>";
} else {
    echo "<p>✗ Rental schedule check failed: " . $schedule['message'] . "</p>";
}

echo "<h3>System Status: ";
if ($availability['status'] == 202 && $availability_tomorrow['status'] == 202 && $schedule['status'] == 202) {
    echo "<span style='color: green;'>ALL TESTS PASSED</span>";
} else {
    echo "<span style='color: red;'>SOME TESTS FAILED</span>";
}
echo "</h3>";

?>