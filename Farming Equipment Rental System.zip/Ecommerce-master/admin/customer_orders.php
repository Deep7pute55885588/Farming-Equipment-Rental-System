<?php session_start(); ?>
<?php include_once("./templates/top.php"); ?>
<?php include_once("./templates/navbar.php"); ?>
<div class="container-fluid">
  <div class="row">
    
    <?php include "./templates/sidebar.php"; ?>

      <div class="row">
      	<div class="col-10">
      		<h2>Orders</h2>
      	</div>
      </div>
      
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Order #</th>
              <th>Equipment Id</th>
              <th>Equipment Name</th>
              <th>Rental Start</th>
              <th>Rental End</th>
              <th>Duration(Hrs)</th>
              <th>Rate/Hr</th>
              <th>Total Cost</th>
              <th>Payment Status</th>
              <th>Customer Name</th>
              <th>Contact</th>
              <th>Email</th>
              <th>Address</th>
			 
            </tr>
          </thead>
					<tbody id="customer_order_list">
					<?php
						// Render orders server-side to avoid client-side caching/mismatch issues
						include_once __DIR__ . '/classes/Customers.php';
						$cust = new Customers();
						$resp = $cust->getCustomersOrder();
						if ($resp['status'] == 202) {
							$i = 0;
							foreach ($resp['message'] as $row) {
								$i++;
								$order_id = $row['order_id'];
								$product_id = $row['product_id'];
								$product_title = isset($row['product_title']) ? $row['product_title'] : '';
								$rstart = isset($row['rental_start_date']) ? $row['rental_start_date'] : '';
								$rend = isset($row['rental_end_date']) ? $row['rental_end_date'] : '';
								$hours = isset($row['duration_hours']) ? $row['duration_hours'] : 0;
								$rate = isset($row['rate_per_hour']) ? number_format($row['rate_per_hour'],2) : '0.00';
								$total = isset($row['total_cost']) ? number_format($row['total_cost'],2) : '0.00';
								$p_status = isset($row['p_status']) ? $row['p_status'] : '';
								$cust_name = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
								$mobile = $row['mobile'] ?? '';
								$email = $row['email'] ?? '';
								$address = trim(($row['address1'] ?? '') . '<br>' . ($row['address2'] ?? ''));
								echo "<tr>";
								echo "<td>#</td>";
								echo "<td>$order_id</td>";
								echo "<td>$product_id</td>";
								echo "<td>$product_title</td>";
								echo "<td>$rstart</td>";
								echo "<td>$rend</td>";
								echo "<td>$hours</td>";
								echo "<td>Rs $rate</td>";
								echo "<td>Rs $total</td>";
								echo "<td>$p_status</td>";
								echo "<td>$cust_name</td>";
								echo "<td>$mobile</td>";
								echo "<td>$email</td>";
								echo "<td>$address</td>";
								echo "</tr>";
							}
						} else {
							echo "<tr><td colspan=14>" . htmlspecialchars($resp['message']) . "</td></tr>";
						}
					?>
					</tbody>
        </table>
      </div>
    </main>
  </div>
</div>



<!-- Modal -->
<div class="modal fade" id="add_product_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Equipment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="add-product-form" enctype="multipart/form-data">
        	<div class="row">
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Equipment Name</label>
		        		<input type="text" name="product_name" class="form-control" placeholder="Enter Product Name">
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Brand Name</label>
		        		<select class="form-control brand_list" name="brand_id">
		        			<option value="">Select Brand</option>
		        		</select>
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Category Name</label>
		        		<select class="form-control category_list" name="category_id">
		        			<option value="">Select Category</option>
		        		</select>
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Equipment Description</label>
		        		<textarea class="form-control" name="product_desc" placeholder="Enter product desc"></textarea>
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Equipment Cost in Rs(for 1 Hour)</label>
		        		<input type="number" name="product_price" class="form-control" placeholder="Enter Product Price">
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Equipment Keywords <small>(eg: tractor, farming, heavy, dig)</small></label>
		        		<input type="text" name="product_keywords" class="form-control" placeholder="Enter Product Keywords">
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Equipment Image <small>(format: jpg, jpeg, png)</small></label>
		        		<input type="file" name="product_image" class="form-control">
		        	</div>
        		</div>
        		<input type="hidden" name="add_product" value="1">
        		<div class="col-12">
        			<button type="button" class="btn btn-primary add-product">Add Equipment</button>
        		</div>
        	</div>
        	
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->

<?php include_once("./templates/footer.php"); ?>



<script type="text/javascript" src="./js/customers.js"></script>