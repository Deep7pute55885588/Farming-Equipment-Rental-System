<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("location:login.php");
    exit;
}
?>
<?php include "./templates/top.php"; ?>
<?php include "./templates/navbar.php"; ?>
<div class="container-fluid">
    <div class="row">
        <?php include "./templates/sidebar.php"; ?>
        <div class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="row">
                <div class="col-12 mt-3">
                    <h2>Equipment Availability Status</h2>
                    <div class="form-group row">
                        <label for="availability_date" class="col-sm-2 col-form-label">Check Availability On:</label>
                        <div class="col-sm-4">
                            <input type="date" class="form-control" id="availability_date" value="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div class="col-sm-2">
                            <button class="btn btn-primary" id="check_availability_btn">Check</button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Equipment</th>
                                    <th>Category</th>
                                    <th>Brand</th>
                                    <th>Total Quantity</th>
                                    <th>Currently Rented</th>
                                    <th>Upcoming Rentals</th>
                                    <th>Available Now</th>
                                </tr>
                            </thead>
                            <tbody id="availability_list">
                                <tr><td colspan="7">Loading availability...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-12">
                    <h2>Rental Schedule</h2>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Equipment</th>
                                    <th>Customer Name</th>
                                    <th>Contact</th>
                                    <th>Quantity</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="schedule_list">
                                <tr><td colspan="8">Loading schedule...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div> <!-- /.col -->
    </div> <!-- /.row -->
</div> <!-- /.container-fluid -->

<?php include "./templates/footer.php"; ?>

<script>
$(document).ready(function(){
    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        text = String(text);
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/\"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function mapStatus(raw) {
        if (raw === null || raw === undefined) return '';
        var s = String(raw).toLowerCase();
        var map = {
            '0': 'Pending',
            '1': 'Confirmed',
            '2': 'Ongoing',
            '3': 'Completed',
            '4': 'Cancelled',
            'pending': 'Pending',
            'confirmed': 'Confirmed',
            'ongoing': 'Ongoing',
            'completed': 'Completed',
            'cancelled': 'Cancelled',
            'active': 'Active'
        };
        return map.hasOwnProperty(s) ? map[s] : String(raw);
    }

    getAvailability();
    getRentalSchedule();

    function getAvailability(date = null) {
        $("#availability_list").html('<tr><td colspan="7">Loading availability...</td></tr>');
        var data = { get_availability: 1 };
        if (date) {
            data.date = date;
        }
        $.ajax({
            url: 'classes/Products.php',
            method: 'POST',
            data: data,
            dataType: 'text',
            success: function(response){
                console.log('Availability response:', response);
                var resp;
                try {
                    resp = (typeof response === 'object') ? response : JSON.parse(response);
                } catch (e) {
                    $("#availability_list").html('<tr><td colspan="7"><pre style="white-space:pre-wrap; color:maroon;">' + escapeHtml(response) + '</pre></td></tr>');
                    return;
                }
                if (resp && (resp.status == 202 || resp.status == 200) && Array.isArray(resp.message) && resp.message.length > 0) {
                    var availabilityHTML = '';
                    $.each(resp.message, function(index, value){
                        var product = escapeHtml(value.product_title || '');
                        var category = escapeHtml(value.cat_title || '');
                        var brand = escapeHtml(value.brand_title || '');
                        var total = escapeHtml(value.total_quantity != null ? value.total_quantity : 0);
                        var rented = escapeHtml(value.currently_rented != null ? value.currently_rented : 0);
                        var upcoming = escapeHtml(value.upcoming_rentals != null ? value.upcoming_rentals : 0);
                        var available = escapeHtml(value.available_quantity != null ? value.available_quantity : 0);
                        availabilityHTML += '<tr>' +
                            '<td>'+ product +'</td>' +
                            '<td>'+ category +'</td>' +
                            '<td>'+ brand +'</td>' +
                            '<td>'+ total +'</td>' +
                            '<td>'+ rented +'</td>' +
                            '<td>'+ upcoming +'</td>' +
                            '<td>'+ available +'</td>' +
                        '</tr>';
                    });
                    $("#availability_list").html(availabilityHTML);
                } else {
                    var msg = (resp && resp.message) ? resp.message : 'No equipment found';
                    var display = (typeof msg === 'string') ? msg : JSON.stringify(msg, null, 2);
                    $("#availability_list").html('<tr><td colspan="7">'+ escapeHtml(display) +'</td></tr>');
                }
            },
            error: function(xhr, status, error) {
                var body = xhr && xhr.responseText ? xhr.responseText : error;
                $("#availability_list").html('<tr><td colspan="7"><pre style="white-space:pre-wrap; color:maroon;">'+ escapeHtml(body) +'</pre></td></tr>');
            }
        });
    }

    function getRentalSchedule() {
        $("#schedule_list").html('<tr><td colspan="8">Loading schedule...</td></tr>');
        $.ajax({
            url: 'classes/Products.php',
            method: 'POST',
            data: { get_rental_schedule: 1 },
            dataType: 'text',
            success: function(response){
                console.log('Schedule response:', response);
                var resp;
                try {
                    resp = (typeof response === 'object') ? response : JSON.parse(response);
                } catch (e) {
                    $("#schedule_list").html('<tr><td colspan="8"><pre style="white-space:pre-wrap; color:maroon;">' + escapeHtml(response) + '</pre></td></tr>');
                    return;
                }
                if (resp && (resp.status == 202 || resp.status == 200) && Array.isArray(resp.message) && resp.message.length > 0) {
                    var scheduleHTML = '';
                    $.each(resp.message, function(index, value){
                        var product = escapeHtml(value.product_title || '');
                        var first = escapeHtml(value.first_name || '');
                        var last = escapeHtml(value.last_name || '');
                        var customer = (first || last) ? (first + (first && last ? ' ' : '') + last) : '';
                        var mobile = escapeHtml(value.mobile || '');
                        var qty = escapeHtml(value.qty != null ? value.qty : 0);
                        var startDate = escapeHtml(value.rental_start_date || '');
                        var endDate = escapeHtml(value.rental_end_date || '');
                        var statusLabel = mapStatus(value.rental_status);
                        var orderId = escapeHtml(value.order_id || '');
                        scheduleHTML += '<tr>' +
                            '<td>'+ product +'</td>' +
                            '<td>'+ customer +'</td>' +
                            '<td>'+ mobile +'</td>' +
                            '<td>'+ qty +'</td>' +
                            '<td>'+ startDate +'</td>' +
                            '<td>'+ endDate +'</td>' +
                            '<td>'+ escapeHtml(statusLabel) +'</td>' +
                            '<td><button class="btn btn-sm btn-success complete-rental" data-order-id="'+orderId+'">Complete Rental</button></td>' +
                        '</tr>';
                    });
                    $("#schedule_list").html(scheduleHTML);
                } else {
                    var msg = (resp && resp.message) ? resp.message : 'No rental schedules found';
                    var display = (typeof msg === 'string') ? msg : JSON.stringify(msg, null, 2);
                    $("#schedule_list").html('<tr><td colspan="8">'+ escapeHtml(display) +'</td></tr>');
                }
            },
            error: function(xhr, status, error) {
                var body = xhr && xhr.responseText ? xhr.responseText : error;
                $("#schedule_list").html('<tr><td colspan="8"><pre style="white-space:pre-wrap; color:maroon;">'+ escapeHtml(body) +'</pre></td></tr>');
            }
        });
    }

    // Check availability for specific date
    $("#check_availability_btn").click(function() {
        var date = $("#availability_date").val();
        if (date) {
            getAvailability(date);
        }
    });

    // Complete rental button handler
    $(document).on('click', '.complete-rental', function() {
        var orderId = $(this).data('order-id');
        if (confirm('Are you sure you want to complete this rental?')) {
            $.ajax({
                url: 'classes/Products.php',
                method: 'POST',
                data: { complete_rental: 1, order_id: orderId },
                dataType: 'json',
                success: function(response) {
                    if (response.status == 202) {
                        alert('Rental completed successfully!');
                        getAvailability(); // Refresh availability
                        getRentalSchedule(); // Refresh schedule
                    } else {
                        alert('Error: ' + response.message);
                    }
                },
                error: function() {
                    alert('Error completing rental');
                }
            });
        }
    });
});
</script>