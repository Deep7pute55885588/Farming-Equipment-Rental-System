$(document).ready(function(){
    // Load data when page loads
    refreshData();

    // Refresh every 30 seconds
    setInterval(refreshData, 30000);

    function refreshData() {
        getAvailability();
        getRentalSchedule();
    }

    function getAvailability() {
        $.ajax({
            url: 'classes/Products.php',
            method: 'POST',
            data: {get_availability: 1},
            success: function(response){
                try {
                    console.log('Availability Response:', response);
                    var resp = JSON.parse(response);
                    if(resp.status == 202 && resp.message && resp.message.length > 0) {
                        var availabilityHTML = '';
                        resp.message.forEach(function(value){
                            availabilityHTML += `
                                <tr>
                                    <td>${value.product_title || 'N/A'}</td>
                                    <td>${value.cat_title || 'N/A'}</td>
                                    <td>${value.brand_title || 'N/A'}</td>
                                    <td>${value.total_quantity || '0'}</td>
                                    <td>${value.currently_rented || '0'}</td>
                                    <td>${value.upcoming_rentals || '0'}</td>
                                    <td>${value.available_quantity || '0'}</td>
                                </tr>`;
                        });
                        $("#availability_list").html(availabilityHTML);
                    } else {
                        $("#availability_list").html('<tr><td colspan="7" class="text-center">No equipment found</td></tr>');
                    }
                } catch(e) {
                    console.error('Error parsing availability response:', e);
                    $("#availability_list").html('<tr><td colspan="7" class="text-center text-danger">Error loading data</td></tr>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                $("#availability_list").html('<tr><td colspan="7" class="text-center text-danger">Failed to load data</td></tr>');
            }
        });
    }

    function getRentalSchedule() {
        $.ajax({
            url: 'classes/Products.php',
            method: 'POST',
            data: {get_rental_schedule: 1},
            success: function(response){
                try {
                    console.log('Schedule Response:', response);
                    var resp = JSON.parse(response);
                    if(resp.status == 202 && resp.message && resp.message.length > 0) {
                        var scheduleHTML = '';
                        resp.message.forEach(function(value){
                            scheduleHTML += `
                                <tr>
                                    <td>${value.product_title || 'N/A'}</td>
                                    <td>${(value.first_name || '') + ' ' + (value.last_name || '')}</td>
                                    <td>${value.mobile || 'N/A'}</td>
                                    <td>${value.qty || '0'}</td>
                                    <td>${value.rental_start_date || 'N/A'}</td>
                                    <td>${value.rental_end_date || 'N/A'}</td>
                                    <td>
                                        <span class="badge badge-${value.rental_status === 'active' ? 'success' : 'secondary'}">
                                            ${value.rental_status || 'N/A'}
                                        </span>
                                    </td>
                                </tr>`;
                        });
                        $("#schedule_list").html(scheduleHTML);
                    } else {
                        $("#schedule_list").html('<tr><td colspan="7" class="text-center">No rental schedules found</td></tr>');
                    }
                } catch(e) {
                    console.error('Error parsing schedule response:', e);
                    $("#schedule_list").html('<tr><td colspan="7" class="text-center text-danger">Error loading schedule</td></tr>');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                $("#schedule_list").html('<tr><td colspan="7" class="text-center text-danger">Failed to load schedule</td></tr>');
            }
        });
    }
});