$(document).ready(function(){

    // Load admin profile data
    function loadAdminProfile() {
        $.ajax({
            url: '../admin/classes/Admin.php',
            method: 'POST',
            data: {GET_ADMIN_PROFILE: 1},
            success: function(response) {
                console.log(response);
                var resp = $.parseJSON(response);
                if(resp.status == 202) {
                    $('#admin-id').val(resp.message.id);
                    $('#admin-name').val(resp.message.name);
                    $('#admin-email').val(resp.message.email);
                    $('#admin-status').val(resp.message.is_active === '1' ? 'Active' : 'Inactive');
                }
            }
        });

        // Load statistics
        $.ajax({
            url: '../admin/classes/Admin.php',
            method: 'POST',
            data: {GET_ADMIN_STATS: 1},
            success: function(response) {
                console.log(response);
                var resp = $.parseJSON(response);
                if(resp.status == 202) {
                    $('#total-products').text(resp.message.total_products);
                    $('#total-orders').text(resp.message.total_orders);
                }
            }
        });
    }

    // Load profile data when page loads
    loadAdminProfile();

    // Handle profile update
    $('.update-profile').on('click', function() {
        var password = $('input[name="password"]').val();
        var confirmPassword = $('input[name="confirm_password"]').val();

        // Check if passwords match if either field is filled
        if(password || confirmPassword) {
            if(password !== confirmPassword) {
                $('.message').html('<div class="alert alert-danger">Passwords do not match!</div>');
                return;
            }
        }

        $.ajax({
            url: '../admin/classes/Admin.php',
            method: 'POST',
            data: $('#admin-profile-form').serialize(),
            success: function(response) {
                console.log(response);
                var resp = $.parseJSON(response);
                if(resp.status == 202) {
                    $('.message').html('<div class="alert alert-success">' + resp.message + '</div>');
                    // Clear password fields after successful update
                    $('input[name="password"]').val('');
                    $('input[name="confirm_password"]').val('');
                    loadAdminProfile(); // Reload the profile data
                } else {
                    $('.message').html('<div class="alert alert-danger">' + resp.message + '</div>');
                }
            }
        });
    });
});