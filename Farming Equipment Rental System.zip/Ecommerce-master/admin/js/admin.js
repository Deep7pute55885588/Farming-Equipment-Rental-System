$(document).ready(function(){
    // Load admin dashboard data
    function loadAdminDashboard() {
        $.ajax({
            // call the Admin class endpoint relative to admin/ folder
            url : 'classes/Admin.php',
            method : 'POST',
            data : {GET_ADMIN_DASHBOARD: 1},
            success : function(response){
                console.log(response);
                var resp = $.parseJSON(response);
                if (resp.status == 202) {
                    const data = resp.message;
                    // Personal Info
                    $('#admin-name').text(data.name || 'Not provided');
                    $('#admin-email').text(data.email || 'Not provided');
                    $('#admin-reg-date').text(data.registration_date || 'Not provided');
                    // Always show Active for account status on dashboard
                    $('#admin-status').text('Active');

                    // Business Stats
                    $('#total-products').text(data.total_products || '0');
                    $('#active-orders').text(data.active_orders || '0');
                    $('#total-orders').text(data.total_orders || '0');
                    $('#total-customers').text(data.total_customers || '0');
                }
                else if (resp.status == 303) {
                    // Not logged in or no data - leave server-side fallback values intact where possible
                    $('#admin-name').text('Not available');
                    $('#admin-email').text('Not available');
                    $('#admin-reg-date').text('Not available');
                    $('#admin-status').text('Not available');

                    $('#total-products').text('0');
                    $('#active-orders').text('0');
                    $('#total-orders').text('0');
                    $('#total-customers').text('0');
                }
            }
        });
    }

    loadAdminDashboard();
});