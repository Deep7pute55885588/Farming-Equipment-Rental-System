function cart_checkout(){
	if(!isset($_SESSION["uid"])){
		echo "<script>window.location.href='index.php'</script>";
	}
	$sql = "SELECT c.*, p.product_title, p.product_price, p.product_image 
			FROM cart c 
			JOIN products p ON c.p_id = p.product_id 
			WHERE c.user_id = '$_SESSION[uid]'";
	$query = mysqli_query($con,$sql);
	if (mysqli_num_rows($query) > 0) {
		while ($row=mysqli_fetch_array($query)) {
			$product_id = $row["p_id"];
			$product_title = $row["product_title"];
			$product_price = $row["product_price"];
			$product_image = $row["product_image"];
			$cart_item_id = $row["id"];
			$qty = $row["qty"];
			$rental_start = $row["rental_start_date"] ? $row["rental_start_date"] : '';
			$rental_end = $row["rental_end_date"] ? $row["rental_end_date"] : '';

			echo '
			<div class="row cart-row">
				<div class="col-md-2">
					<div class="btn-group">
						<a href="#" remove_id="'.$product_id.'" class="btn btn-danger remove"><span class="glyphicon glyphicon-trash"></span></a>
						<a href="#" update_id="'.$product_id.'" class="btn btn-primary update"><span class="glyphicon glyphicon-ok-sign"></span></a>
					</div>
				</div>
				<div class="col-md-2"><img src="product_images/'.$product_image.'" width="60px" height="60px"></div>
				<div class="col-md-2">'.$product_title.'</div>
				<div class="col-md-2">
					<input type="date" class="form-control rental-start" name="rental_start_date[]" value="'.$rental_start.'" required>
				</div>
				<div class="col-md-2">
					<input type="date" class="form-control rental-end" name="rental_end_date[]" value="'.$rental_end.'" required>
				</div>
				<div class="col-md-1">
					<input type="number" class="form-control hours" readonly>
				</div>
				<div class="col-md-1">
					<input type="number" class="form-control rate-per-hour" value="'.$product_price.'" readonly>
				</div>
				<div class="col-md-2">
					<input type="number" class="form-control total-cost" readonly>
					<input type="hidden" name="rental_hours[]">
				</div>
			</div>';
		}
		echo '
		<div class="row">
			<div class="col-md-8"></div>
			<div class="col-md-4">
				<b>Total Rental Cost: Rs.<span id="total_rental_cost">0.00</span></b>
			</div>
		</div>';
	}
}