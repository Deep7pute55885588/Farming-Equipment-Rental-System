<?php
// This script automatically adjusts equipment availability based on rental dates
// It should be run as a cron job daily

// Start session to access admin session if needed
session_start();

// Include database connection
include_once "classes/Database.php";
include_once "classes/Products.php";

// Create database connection
$db = new Database();
$con = $db->connect();

// Create Products instance
$products = new Products();

// Run the automatic adjustment
$result = $products->autoAdjustEquipmentAvailability();

// Log the result
$log_message = date('Y-m-d H:i:s') . " - Auto-adjust equipment availability result: " . json_encode($result) . "\n";
file_put_contents('logs/auto_adjust_log.txt', $log_message, FILE_APPEND | LOCK_EX);

echo "Equipment availability adjustment completed.\n";
echo "Result: " . json_encode($result) . "\n";
?>