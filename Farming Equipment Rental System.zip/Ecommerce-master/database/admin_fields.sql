-- Add new columns to admin table for registration information
ALTER TABLE `admin` 
ADD `phone` varchar(15) DEFAULT NULL AFTER `email`,
ADD `address` text DEFAULT NULL AFTER `phone`,
ADD `city` varchar(100) DEFAULT NULL AFTER `address`,
ADD `state` varchar(100) DEFAULT NULL AFTER `city`,
ADD `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `is_active`;