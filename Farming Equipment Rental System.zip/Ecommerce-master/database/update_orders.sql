ALTER TABLE orders
ADD COLUMN rental_start_date DATE,
ADD COLUMN rental_end_date DATE,
ADD COLUMN rental_status ENUM('active', 'completed', 'cancelled') DEFAULT 'active';