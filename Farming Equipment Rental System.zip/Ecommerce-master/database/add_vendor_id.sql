-- Add vendor_id column to products table if it doesn't exist
SET @columnExists = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = 'store_db' 
                     AND TABLE_NAME = 'products' 
                     AND COLUMN_NAME = 'vendor_id');

SET @sql = IF(@columnExists = 0, 
              'ALTER TABLE products ADD COLUMN vendor_id INT(11) DEFAULT 0', 
              'SELECT ''Column already exists''');

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;