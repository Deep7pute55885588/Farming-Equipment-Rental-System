-- Add rental dates to cart table
ALTER TABLE cart
ADD COLUMN rental_start_date DATE,
ADD COLUMN rental_end_date DATE;

-- Add rental dates to orders table
ALTER TABLE orders
ADD COLUMN rental_start_date DATE,
ADD COLUMN rental_end_date DATE;