$(document).ready(function(){
        // initialize
        cat();
        brand();
        product();

        // fetch categories
        function cat(){
            $.ajax({
                url: "action.php",
                method: "POST",
                data: { category: 1 },
                success: function(data){
                    $("#get_category").html(data);
                }
            });
        }

        // fetch brands
        function brand(){
            $.ajax({
                url: "action.php",
                method: "POST",
                data: { brand: 1 },
                success: function(data){
                    $("#get_brand").html(data);
                }
            });
        }

        // fetch products
        function product(){
            $.ajax({
                url: "action.php",
                method: "POST",
                data: { getProduct: 1 },
                success: function(data){
                    $("#get_product").html(data);
                }
            });
        }

        // category click -> show products
        $('body').on('click', '.category', function(event){
            event.preventDefault();
            $("#get_product").html("<h3>Loading...</h3>");
            var cid = $(this).attr('cid');
            $.ajax({
                url: "action.php",
                method: "POST",
                data: { get_seleted_Category: 1, cat_id: cid },
                success: function(data){
                    $("#get_product").html(data);
                    if($(window).width() < 480){
                        $('html,body').scrollTop(683);
                    }
                }
            });
        });

        // brand click -> show products
        $('body').on('click', '.selectBrand', function(event){
            event.preventDefault();
            $("#get_product").html("<h3>Loading...</h3>");
            var bid = $(this).attr('bid');
            $.ajax({
                url: "action.php",
                method: "POST",
                data: { selectBrand: 1, brand_id: bid },
                success: function(data){
                    $("#get_product").html(data);
                    if($(window).width() < 480){
                        $('html,body').scrollTop(683);
                    }
                }
            });
        });

        // search
        $("#search_btn").click(function(){
            $("#get_product").html("<h3>Loading...</h3>");
            var keyword = $("#search").val();
            if(keyword !== ""){
                $.ajax({
                    url: "action.php",
                    method: "POST",
                    data: { search: 1, keyword: keyword },
                    success: function(data){
                        $("#get_product").html(data);
                        if($(window).width() < 480){
                            $('html,body').scrollTop(683);
                        }
                    }
                });
            }
        });

        // add product to cart
        $('body').on('click', '#product', function(event){
            event.preventDefault();
            var pid = $(this).attr('pid');
            $('.overlay').show();
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { addToCart: 1, proId: pid },
                success: function(data){
                    count_item();
                    getCartItem();
                    $('#product_msg').html(data);
                    $('.overlay').hide();
                }
            });
        });

        // count items
        count_item();
        function count_item(){
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { count_item: 1 },
                success: function(data){
                    $('.badge').html(data);
                }
            });
        }

        // get cart items (dropdown)
        getCartItem();
        function getCartItem(){
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { Common: 1, getCartItem: 1 },
                success: function(data){
                    $('#cart_product').html(data);
                }
            });
        }

        // qty change
        $('body').on('keyup', '.qty', function(event){
            event.preventDefault();
            var row = $(this).closest('tr');
            var price = parseFloat(row.find('.price').val()) || 0;
            var qty = parseInt(row.find('.qty').val()) || 1;
            if(isNaN(qty) || qty < 1) qty = 1;
            var total = price * qty;
            row.find('.total').val(total);
            var net_total = 0;
            $('.total').each(function(){ net_total += (parseFloat($(this).val())||0); });
            $('.net_total').html('Total :Rs ' + net_total);
        });

        // remove item
        $('body').on('click', '.remove', function(event){
            event.preventDefault();
            var row = $(this).closest('tr');
            var remove_id = $(this).attr('remove_id');
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { removeItemFromCart: 1, rid: remove_id },
                success: function(data){
                    $('#cart_msg').html(data);
                    checkOutDetails();
                }
            });
        });

        // update qty server-side
        $('body').on('click', '.update', function(event){
            event.preventDefault();
            var row = $(this).closest('tr');
            var update_id = $(this).attr('update_id');
            var qty = row.find('.qty').val();
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { updateCartItem: 1, update_id: update_id, qty: qty },
                success: function(data){
                    $('#cart_msg').html(data);
                    checkOutDetails();
                }
            });
        });

        // checkout details
        checkOutDetails();
        function checkOutDetails(){
            $('.overlay').show();
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { Common:1, checkOutDetails: 1 },
                success: function(data){
                    $('.overlay').hide();
                    $('#cart_checkout').html(data);
                    net_total();
                }
            });
        }

        // calculate totals
        function net_total(){
            var net_total = 0;
            $('.qty').each(function(){
                var row = $(this).closest('tr');
                var price = parseFloat(row.find('.price').val()) || 0;
                var total = price * (parseInt($(this).val())||0);
                row.find('.total').val(total);
            });
            $('.total').each(function(){ net_total += (parseFloat($(this).val())||0); });
            $('.net_total').html('Total : Rs ' + net_total);
        }

        // pagination
        page();
        function page(){
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { page: 1 },
                success: function(data){ $('#pageno').html(data); }
            });
        }

        $('body').on('click', '#page', function(){
            var pn = $(this).attr('page');
            $.ajax({
                url: 'action.php',
                method: 'POST',
                data: { getProduct:1, setPage:1, pageNumber: pn },
                success: function(data){ $('#get_product').html(data); }
            });
        });

        // Login form submission
        $(document).on("submit", "#login", function(event){
            event.preventDefault();
            console.log("Login form submitted");
            
            var email = $("#email").val();
            var password = $("#password").val();
            
            if(email == "" || password == ""){
                $("#e_msg").html("<span style='color:red;'>Please fill all fields</span>");
                return;
            }
            
            $.ajax({
                url : "login.php",
                method: "POST",
                data: {email: email, password: password},
                success: function(data){
                    console.log("Login response:", data);
                    if(data.trim() == "login_success"){
                        console.log("Redirecting to profile.php");
                        window.location.href = "profile.php";
                    }else if(data.trim() == "cart_login"){
                        console.log("Redirecting to cart.php");
                        window.location.href = "cart.php";
                    }else{
                        $("#e_msg").html(data);
                    }
                },
                error: function(xhr, status, error) {
                    console.log("AJAX Error:", error);
                    $("#e_msg").html("<span style='color:red;'>An error occurred: " + error + "</span>");
                }
            });
        });

        // Registration form submission
        $(document).on("submit", "#signup_form", function(event){
            event.preventDefault();
            var f_name = $("#f_name").val();
            var l_name = $("#l_name").val();
            var email = $("#email").val();
            var password = $("#password").val();
            var repassword = $("#repassword").val();
            var mobile = $("#mobile").val();
            var address1 = $("#address1").val();
            var address2 = $("#address2").val();
            
            if(f_name == "" || l_name == "" || email == "" || password == "" || repassword == "" || mobile == "" || address1 == "" || address2 == ""){
                $("#signup_msg").html("<span style='color:red;'>Please fill all fields</span>");
                return;
            }
            
            if(password != repassword){
                $("#signup_msg").html("<span style='color:red;'>Password does not match</span>");
                return;
            }
            
            $.ajax({
                url : "register.php",
                method: "POST",
                data: $("#signup_form").serialize(),
                success: function(data){
                    if(data == "register_success"){
                        window.location.href = "login_form.php";
                    }else{
                        $("#signup_msg").html(data);
                    }
                },
                error: function(xhr, status, error) {
                    $("#signup_msg").html("<span style='color:red;'>An error occurred: " + error + "</span>");
                }
            });
        });
    });