<?php
session_start();
include "db.php";

if (!isset($_SESSION['uid'])) {
    echo json_encode(['status'=>'error','message'=>'Please login first']);
    exit();
}

// Expect arrays: ids[], start_dates[], end_dates[]
$ids = isset($_POST['ids']) ? $_POST['ids'] : [];
$starts = isset($_POST['starts']) ? $_POST['starts'] : [];
$ends = isset($_POST['ends']) ? $_POST['ends'] : [];

if (!is_array($ids) || !is_array($starts) || !is_array($ends)) {
    echo json_encode(['status'=>'error','message'=>'Invalid input']);
    exit();
}

$uid = $_SESSION['uid'];

for ($i=0; $i<count($ids); $i++) {
    $pid = intval($ids[$i]);
    $s = mysqli_real_escape_string($con, $starts[$i]);
    $e = mysqli_real_escape_string($con, $ends[$i]);

    // If both dates present, validate
    if (!empty($s) && !empty($e)) {
        if (strtotime($s) < strtotime('today')) {
            echo json_encode(['status'=>'error','message'=>"Start date cannot be in the past for product $pid"]);
            exit();
        }
        if (strtotime($e) <= strtotime($s)) {
            echo json_encode(['status'=>'error','message'=>"End date must be after start date for product $pid"]);
            exit();
        }
    }

    // Update (allow empty dates to clear)
    $sql = "UPDATE cart SET rental_start_date = '".$s."', rental_end_date = '".$e."' WHERE p_id = '$pid' AND user_id = '$uid'";
    mysqli_query($con, $sql);
}

// Recalculate finalcost
$final = 0;
$calc_sql = "SELECT a.product_price, b.rental_start_date, b.rental_end_date, b.qty FROM products a, cart b WHERE a.product_id=b.p_id AND b.user_id='$uid'";
$calc_q = mysqli_query($con, $calc_sql);
if ($calc_q) {
    while ($r = mysqli_fetch_array($calc_q)) {
        $pprice = $r['product_price'];
        $rs = $r['rental_start_date'];
        $re = $r['rental_end_date'];
        $q = $r['qty'];
        if (!empty($rs) && !empty($re)) {
            $hours = ceil((strtotime($re) - strtotime($rs)) / 3600);
            if ($hours < 1) $hours = 1;
            $final += $pprice * $hours;
        } else {
            $final += $pprice * $q;
        }
    }
}
$_SESSION['finalcost'] = $final;

echo json_encode(['status'=>'ok','finalcost'=>$final]);
exit();

?>
