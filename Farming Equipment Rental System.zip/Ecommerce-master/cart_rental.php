<?php
session_start();
include "db.php";

if(isset($_POST['addToRent'])) {
    if(!isset($_SESSION["uid"])) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Please login first to rent equipment!',
            'redirect' => 'login.php'
        ]);
        exit();
    }

    $p_id = $_POST["proId"];
    $user_id = $_SESSION["uid"];
    $start_date = $_POST["rental_start"];
    $end_date = $_POST["rental_end"];
    
    // Validate dates
    if (strtotime($start_date) < strtotime('today')) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Start date cannot be in the past!'
        ]);
        exit();
    }
    
    if (strtotime($end_date) <= strtotime($start_date)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'End date must be after start date!'
        ]);
        exit();
    }

    // Calculate rental hours
    $hours = ceil((strtotime($end_date) - strtotime($start_date)) / (60 * 60));
    
    // Get product price
    $sql = "SELECT product_price FROM products WHERE product_id = '$p_id'";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_assoc($result);
    $price_per_hour = $row['product_price'];
    
    // Calculate total cost
    $total_cost = $hours * $price_per_hour;
    
    // Add to cart
    $sql = "INSERT INTO cart 
            (p_id, ip_add, user_id, qty, rental_start_date, rental_end_date, total_cost) 
            VALUES ('$p_id', '$ip_add', '$user_id', 1, '$start_date', '$end_date', '$total_cost')";
    
    if(mysqli_query($con, $sql)) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Equipment added to cart with rental dates!',
            'cart_count' => true
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to add equipment to cart. Please try again.'
        ]);
    }
    exit();
}
?>