<?php
session_start();
if(isset($_SESSION["uid"])){
	header("location:profile.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>FARMTECH</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<script src="https://kit.fontawesome.com/26504e4a1f.js" crossorigin="anonymous"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" type="text/css" href="instyle.css">
		<link rel="stylesheet" type="text/css" href="css/rental.css">
		<style></style>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand"><img src="product_images/EASLogo4.jpg" alt="FARMTECH"></a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="productview.php"><span class="glyphicon glyphicon-modal-window"></span>Equipments</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span>Cart<span class="badge">0</span></a>
				<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
							<div class="panel-heading"><center><h4>Login First Before Cart</h4></center></div>
								<div class="panel-heading"><center><h4>Login</h4></center></div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<br> 	
										<center>
											<input type="submit" class="btn btn-success" style="float:center; "><br>
											<a href="customer_registration.php?register=1" style="color:white; list-style:none;">New Here! Create an account!</a><br>
											<a href="admin/index.php" style="color:orange; list-style:none;">Login as Vendor</a><br>
										</center>
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
				</li>
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>SignIn</a>
					<ul class="dropdown-menu">
						<div style="width:300px;">
							<div class="panel panel-primary">
								<div class="panel-heading"><center><h4>Login</h4></center></div>
								<div class="panel-heading">
									<form onsubmit="return false" id="login">
										<label for="email">Email</label>
										<input type="email" class="form-control" name="email" id="email" required/>
										<label for="email">Password</label>
										<input type="password" class="form-control" name="password" id="password" required/>
										<br> 	
										<center>
											<input type="submit" class="btn btn-success" style="float:center; "><br>
											<a href="customer_registration.php?register=1" style="color:white; list-style:none;">New Here! Create an account!</a><br>
											<a href="admin/index.php" style="color:orange; list-style:none;">Login as Vendor</a><br>
										</center>
									</form>
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>


<section class="home" id="home" >
	<div class="content">
		<h2>FARMTECH!</h2>
		<h4>Farming Made Easy,with FARMTECH<br>
			Tools for Every Field, Anytime You Need</h4>
	</div> 

	
</section>

<section class="features" id="features">
	<h1 class="heading">Our<span>Features</span></h1>
	<div class="box-container">
		<div class="box">
			<img src="product_images/durablelogo.jpg" alt="">
			<h3>Durability</h3>
			<p>We only supply Durable equipments/products</p>
		</div>

		<div class="box">
			<img src="product_images/qualitylogo.jpg" alt="">
			<h3>Quality Equipments</h3>
			<p>We only provide Quality and Branded products and equipments</p>
		</div>

		<div class="box">
			<img src="product_images/paylogo.jpeg" alt="">
			<h3>Easy Payments</h3>
			<p>Customers get Easy and Secure Payment environment</p>
		</div>
	</div>
</section>

<section class="categories" id="categories">

	<h1 class="heading">Farmer<span>Categories</span></h1>

	<div class="box-container">
		<div class="box">
			<img src="product_images/grapes.png" alt="">
			<h3>Grapes Farmer Equipment</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/rice.png" alt="">
			<h3>Rice Farmer Equipments</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/apple.png" alt="">
			<h3>Apple Farmer Equipments</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/coffee.png" alt="">
			<h3>Coffee Farmer Equipments</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/cocoa.png" alt="">
			<h3>Cocoa Farmer Equipments</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

	</div>	
</section>

<section class="brands" id="brands">

	<h1 class="heading">Top<span>Brands</span></h1>

	<div class="box-container">
		<div class="box">
			<img src="product_images/Mahindra-logo.png" alt="">
			<h3>Mahindra</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/tatalogo.png" alt="">
			<h3>TATA</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/JCB-Logo.jpg" alt="">
			<h3>JCB</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/agtlogo.png" alt="">
			<h3>AGT</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/allogo.png" alt="">
			<h3>Ashok Leyland</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

		<div class="box">
			<img src="product_images/catlogo.jpeg" alt="">
			<h3>Caterpillar inc</h3>
			<a href="productview.php" class="btn">Shop Now</a>
		</div>

	</div>	
</section>
<br>
<section class="footer">
	<div class="box-container">
		<div class="box">
			<h3>FARMTECH</h3>
			<p class="off"> <i class="fa fa-building-o"></i> Computer Dept., S.V.K.M IOT, Dhule,Dhule</p>
			<div class="share">
				<a href="https://www.facebook.com/deep.satpute.946" target="_blank" class="fab fa-facebook-f"></a>
				<a href="https://twitter.com/satputedeep9" target="_blank" class="fab fa-twitter"></a>
				<a href="https://www.instagram.com/deep_satpute/" target="_blank" class="fab fa-instagram"></a><br><br>
				<a href='https://www.free-counters.org/'><i class="fa fa-user-circle" aria-hidden="true"></i>User Visited</a><script type="text/javascript" src="https://www.freevisitorcounters.com/en/home/counter/1169290/t/5"></script>
			</div>
		</div>

		<div class="box">
			<h3>Contact Info</h3>
			<a href="#" class="links"> <i class="fas fa-phone"></i> 9373810854 </a>
			<a href="#" class="links"> <i class="fas fa-phone"></i> 9422788414 </a>
			<a href="https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&emr=1&followup=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&osid=1&passive=1209600&service=mail&ifkv=ARZ0qKJ44eMdUj1t3CovyhRPrBOpaYgLmWu3aQk2lGe0F-MFASqISNGV-VXerilk0K9EAghlfWtD_A&theme=mn&ddm=0&flowName=GlifWebSignIn&flowEntry=ServiceLogin" class="links"> <i class="fas fa-envelope"></i> satputedeep9@gmail.com </a> 
			<a href="https://www.google.com/maps/place/SVKM's+Institute+of+Technology/@20.8705274,74.7659377,17z/data=!3m1!4b1!4m6!3m5!1s0x3bdec60f78cc96db:0x6ae5738a6d39c455!8m2!3d20.8705224!4d74.7685126!16s%2Fg%2F11g6_64sk4?entry=ttu&g_ep=EgoyMDI1MDUxMi4wIKXMDSoASAFQAw%3D%3D" class="links"> <i class="fas fa-map-marker-alt"></i> Dhule, Maharashtra-424002,India </a>
		</div>
		
		<div class="box">
			<h3>Quick Links</h3>
			<a href="index.php" class="links"> <i class="fas fa-arrow-right"></i> Home </a>
			<a href="productview.php" class="links"> <i class="fas fa-arrow-right"></i> Equipments </a> 
			<a href="login_form.php" class="links"> <i class="fas fa-arrow-right"></i> Customer Login </a>
			<a href="admin/index.php" class="links"> <i class="fas fa-arrow-right"></i> Admin/Vendor Login </a>
		</div>
	</div>
	<div class="credit">Created by <span>S.V.K.M Computer dept. Students </span> | All Rights Reserved </div>
</section>


</body>
</html>